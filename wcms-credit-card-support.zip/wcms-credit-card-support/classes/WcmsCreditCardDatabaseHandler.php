<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

require_once(dirname(__FILE__) . '/../constants/wcms_credit_cards_globals.php');

class WcmsCreditCardDatabaseHandler{
    // instance of singleton class
    protected static $instance = null;
	
    private function __construct(){
    }

    /**
     * method lazy creates one instance of WcmsCreditCardDatabaseHandler
     * and retunrs an instance of this object.
     *
     * @return null|WcmsCreditCardDatabaseHandler
     */
    public static function getInstance(){
        if (!isset(self::$instance)) {
            self::$instance = new WcmsCreditCardDatabaseHandler();
        }
        return self::$instance;
    }

    /**
     * Creates database tables for receiving FeedX
     */
    public function createTables(){
        
        global $wpdb;

        require_once( ABSPATH . WP_PATH_UPGRAGE_DB );

        $charset_collate = $wpdb->get_charset_collate();
        $sql = $this->getSql_createCreditCardsTable($wpdb->prefix, $charset_collate);
        dbDelta( $sql );
        $sql = $this->getSql_createCreditCardVersionTable($wpdb->prefix, $charset_collate);
        dbDelta( $sql );
        $sql = $this->getSql_createCreditCardUserToTokenTable($wpdb->prefix, $charset_collate);
        dbDelta( $sql );
    }

    /**
     * @param $queryStr
     * @param string $queryType
     * @param array $param_array
     * @return array|int|null|object|string
     *
     *
     * Wrapper for running WP_Query stuff
     */
    public function runQuery($queryStr, $queryType = CREDIT_CARD_QUERY_TYPE_IGNORE, $param_array = array()){
		
		global $wpdb;
		
        $sql = $wpdb->prepare($queryStr,$param_array);
		
        $result = "";
        if ($sql){
           $result = $wpdb->get_results($sql,ARRAY_A);
           if ($queryType == CREDIT_CARD_QUERY_TYPE_INSERT){
                $result = $wpdb->insert_id;
           }
        }
		
		// error handling
		if( !empty($wpdb->last_error)) {
			error_log( __FUNCTION__ ."(): SQL Error - ".$wpdb->last_error);
			return array();
		}
        return $result ;
    }

    /**
     * @param $cardVersionId
     * @param $metaKey
     * @param $metaValue
     * @return array|int|null|object|string
     */
    public function insertCreditCardMetaValue($cardVersionId, $metaKey, $metaValue){
		
		global $wpdb;
		
        $sqlStr = "INSERT INTO ".CREDIT_CARD_TABLE_NAME." (`" .
                   CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID."`, `".
                   CREDIT_CARD_TABLE_FIELD_META_KEY."`, `".
                   CREDIT_CARD_TABLE_FIELD_META_VALUE."`, `".
                   CREDIT_CARD_TABLE_FIELD_TIME_CREATION."`) 
                   VALUES ('".$cardVersionId."', '".$metaKey."', %s, CURRENT_DATE())";

        $result = $this->runQuery($sqlStr, CREDIT_CARD_QUERY_TYPE_INSERT, array($metaValue));

        return $result;

    }

    /**
     * @param $cardId
     * @param $config
     * @return array|int|null|object|string
     *
     * Insert latest version of credit card data, appropriately marked
     */
    public function insertCreditCardVersion($cardId, $config){

        $sqlStr = "INSERT INTO ".CREDIT_CARD_VERSIONS_TABLE_NAME." (`" .
            CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME."`, `".
            CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID."`, `".
			CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME."`, `".
            CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION."`, `".
            CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."`, `".
            CREDIT_CARD_VERSIONS_TABLE_FIELD_TIME_CREATION."`) 
            VALUES  ( '".
            $cardId.
            "', '".
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID].
            "', '".
			$config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME].
            "', '".
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION].
            "', '".
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE].
            "', CURRENT_DATE())";

        $result = $this->runQuery($sqlStr, CREDIT_CARD_QUERY_TYPE_INSERT);
        return $result;
    }

    /**
     * @param $cardId
     * @param $version
     * @param $status
     * @param string $currentVersionNewStatus
     * @return array|int|null|object|string
     *
     * Set whether cards are ACTIVE or ARCHIVED.
     */
    public function changeCardStateByVersion($cardId, $version,  $status, $currentVersionNewStatus = CREDIT_CARD_STATUS_ARCHIVE ){

        // set version number $version of $cardId to be with status $status version
        $sqlStr = "UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."=".$this->valueToQueryStr($status).
                " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME." LIKE ".$this->valueToQueryStr($cardId).
                " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." LIKE ".$this->valueToQueryStr($version);

        $result = $this->runQuery($sqlStr);

        // if the status of the new version is active,
        // set previous versions state of this cardId as archive
        if ($status == CREDIT_CARD_STATUS_ACTIVE){
            $sqlStr = "UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
            " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."=".$this->valueToQueryStr($currentVersionNewStatus).
            " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME."=".$this->valueToQueryStr($cardId).
            " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." NOT LIKE ".$this->valueToQueryStr($version);

            $result = $this->runQuery($sqlStr);
        }

        return $result;
    }


    /**
     * @param $id
     * @param $version
     * @param $status
     * @param string $currentVersionNewStatus
     * @return array|int|null|object|string
     *
     * Change card status by issuing bank
     *
     */
    public function changeCardVersionByAdvertiserId($id, $version,  $status, $currentVersionNewStatus = CREDIT_CARD_STATUS_ARCHIVE ){

        // set version number $version of $id to be with status $status version
        $sqlStr = "UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
            " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."=".$this->valueToQueryStr($status).
            " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." LIKE ".$this->valueToQueryStr($id).
            " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." LIKE ".$this->valueToQueryStr($version);

        $result = $this->runQuery($sqlStr);

        // if the status of the new version is active,
        // set previous versions state of this advertiser as archive
        if ($status == CREDIT_CARD_STATUS_ACTIVE){
            $sqlStr = "UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."=".$this->valueToQueryStr($currentVersionNewStatus).
                " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID."=".$this->valueToQueryStr($id).
                " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." NOT LIKE ".$this->valueToQueryStr($version);

            $result = $this->runQuery($sqlStr);
        }

        return $result;
    }

    /**
     * method update card records with $cardId
     * having on of $oldstates to $newState
     * and make sure that if version already exists 
     * dont make changes, because it must be a mistake,
     * every change on card derives a new version number
     * 
     */
    public function updateCardState($cardId, $oldStates, $newState, $version){

        $oldStatesStr = $this->arrayToQueryStringArray($oldStates);

        $sqlStr = " UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                  " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."=".$this->valueToQueryStr($newState).
                  " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME."=".$this->valueToQueryStr($cardId).
                  " AND ". CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE ." IN ".$oldStatesStr.
                  " AND ". CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION ." NOT LIKE ".$this->valueToQueryStr($version) ;

        $result = $this->runQuery($sqlStr);
        return $result;
    }

    /**
     * @param $cardId
     * @param $config
     * @param string $state
     * @return array|int|null|object|string
     *
     * Set cards to archived
     *
     */
    private function updateCreditCardOldVersionState($cardId, $config, $state = CREDIT_CARD_STATUS_ARCHIVE){

        $sqlStr = " UPDATE ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                  " SET ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE."='".$state.
                  "' WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME."='".$cardId.
                  "' AND ". CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION ." NOT LIKE ".$config[CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION] ;

        $result = $this->runQuery($sqlStr);
        return $result;

    }

    /**
     * Method get a $card which is json formated that contains all
     * cards with a key value, mapping.
     *
     * @param $card
     * @return mixed
     */
    public function insertCreditCard($card, $cardVersionId){
       foreach($card as $key => $value) {
           // This meta field is the card image.
           if ($key === 'feedx_card_image' && filter_var($value, FILTER_VALIDATE_URL)) {
               // Insert it into the WordPress media library.
               WcmsCreditCardHandler::insertCreditCardImageFileToMediaLibrary($cardVersionId, $value);
           }

            $this->insertCreditCardMetaValue(
               $cardVersionId,
               $key,
               $value
            );
       }
    }

    /**
     * @param $config
     * @return array|int|null|object|string
     *
     * Validation
     *
     */
    private function verifyCardVersionExists($config){
        $sqlStr = "SELECT version FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME.
        " WHERE version=".$config[CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION].
        " AND ". CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." = ".$this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]).
        " GROUP BY ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION;

        $result = $this->runQuery($sqlStr);
        return $result;
    }

    /**
     * @param $cards
     * @param $config
     * @return array
     *
     * Main function. Received CONFIG and CARDS data separated from the original input JSON,
     * and performs queries
     */
    public function handleCreditCardRequest($cards ,$config){

        $isConfigValidationOk = $this->validateConfig($config);
        if (!$isConfigValidationOk){
            return array(
                RESPONSE_OBJ_KEY_RESULT => false
            );
        }

        $isCardVersionExists = $this->verifyCardVersionExists($config);

        switch ($config[REQUEST_PARAM_TYPE]){
            case REQUEST_TYPE_UPDATE :
                if(!empty($isCardVersionExists)) {
                    // just look at config to update version
                    $result = $this->changeCardsStateByVersion($cards, $config);
                }
                break;
            case REQUEST_TYPE_ADD :
                if(empty($isCardVersionExists)) {
                    // remove old card version according to maximum allowed versions to advertiser
                    $this->removeOldCardVersion($config);
                    $result = $this->insertCreditCards($cards, $config);
                }
                break;
        }

        // this should only run if the result has a SUCCESS code (see global constants)

        return array(
            RESPONSE_OBJ_KEY_RESULT => $result,
            RESPONSE_OBJ_KEY_VERSION_EXISTS => count($isCardVersionExists)>0 ? true : false
        );
    }

    /**
     * @param $cards
     * @param $config
     * @return bool
     *
     * Change card state by version
     */
    public function changeCardsStateByVersion($cards, $config){

        $result = !empty($cards) ? true : false;

        $this->changeCardVersionByAdvertiserId(
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID],
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION],
            $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE]
        );

        return $result;
    }

    /**
     * @param $cards
     * @param $config
     * @return bool
     *
     * Inserts the cards
     */
    public function insertCreditCards($cards, $config){
        $result = !empty($cards) ? true : false;
		
        // THM-15006: Force HTTPS for images
		foreach($cards as $idx => $card){
            $cards[$idx]['feedx_card_image'] = preg_replace("/^http:/i", "https:", trim($card['feedx_card_image']));
		}
		
        foreach($cards as $card){
            
            // THM-13660 bugfix - some cards like Capital One pass text fields as arrays.
            // Check that all fields are not arrays, and if they are arrays, then make them strings
			foreach( $card as $meta_key => $meta_value ) {
				if( is_array($meta_value) ) {
					$card[$meta_key] = implode(", ", $meta_value);
				}
			}
			
            // if the config file holds an active version, 
            // set active versions state of the advertiser to archive
            if ($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE] == CREDIT_CARD_STATUS_ACTIVE){
                $this->updateCreditCardOldVersionState(
                    $card[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME], 
                    $config,
                    CREDIT_CARD_STATUS_ARCHIVE
                ); 
            }

            // insert new credit card version to CREDIT_CARD_VERSIONS_TABLE
			$cardVersionId = $this->insertCreditCardVersion(
                $card[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME], 
                $config
            );
            // insert new credit card version to CREDIT_CARD_TABLE
            $this->insertCreditCard($card, $cardVersionId);
        }

        // update the brands that already have card data matched to them
        $this->updateCardsMatchedToBrands($cards, $config);
        return $result;
    }
    /**
     * verify that all parameters from $config exist
     *
     * Validate card against schema
     * 
     */
    public function validateConfig($config){
        $isConfigValidationOk = true;

        $configArray = array(
            REQUEST_PARAM_SUB_TYPE => array(REQUEST_SUB_TYPE_UPDATE_SCHEMA,
                REQUEST_SUB_TYPE_UPDATE_CARDS_VERSION,
                REQUEST_SUB_TYPE_UPDATE_CONFIG_SETTINGS,
                REQUEST_SUB_TYPE_ADD_NEW_CARDS
            ),
            REQUEST_PARAM_TYPE => array(REQUEST_TYPE_ADD, REQUEST_TYPE_UPDATE),
            REQUEST_PARAM_STATE => array(CREDIT_CARD_STATUS_ACTIVE, CREDIT_CARD_STATUS_ARCHIVE, CREDIT_CARD_STATUS_PENDING)
        );

        foreach ($config as  $key => $value){
            if (!empty($configArray[$key])){
                $isConfigValidationOk = $isConfigValidationOk && in_array($value, $configArray[$key]);
            }
        }

        return $isConfigValidationOk;
    }

    /**
     * @param string $cardId 
     * @param string $bank 
     * @param array $parameters
     * @param bool $getCardKeyValueData
     * @return array|int|null|object|string
     *
     * Get card by cardID
     */
    public function getCard($cardId, $bank = false, $parameters = array(), $getCardKeyValueData = true){

        $selectedFieldsStr = "*";
        if ($getCardKeyValueData){
            $selectedFieldsStr = CREDIT_CARD_TABLE_FIELD_META_KEY.",".CREDIT_CARD_TABLE_FIELD_META_VALUE;
        }

        // replace special characters with "%%" in order to properly escape them, for WP prepared statements.
        // this does not break normal SQL syntax, but it looks a little weird. Yay, documentation.
        $cardId = $this->wipeAllHTMLSpecialChars( $cardId, '%%' );

        $sqlStr = "SELECT cv.".CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID.", cv.".FEEDX_UNIQUE_NAME_FIELD.", 
                    cc.".CREDIT_CARD_TABLE_FIELD_META_KEY.", cc.".CREDIT_CARD_TABLE_FIELD_META_VALUE."
                     
                    FROM ".CREDIT_CARD_TABLE_NAME." cc, ".CREDIT_CARD_VERSIONS_TABLE_NAME." cv
                    WHERE cc.".CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID." = cv.".CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID." 
                    AND cv.".FEEDX_UNIQUE_NAME_FIELD." LIKE %s 
                    AND cv.state LIKE 'active'";

        $prepared_placeholders = array($cardId);

        // if there is a BANK param, it is checked against two fields,
        // so it will have two placeholders in the prepared statement
        // and needs to be in the "prepared values" array twice.
        if( $bank !== false) {
            $sqlStr .= " AND (cv.".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID . " = %s OR " .
                " cv.". CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME . " = %s )";

            array_push($prepared_placeholders, $bank, $bank);
        }

        if (!empty( $parameters)){
            $parametersStr = $this->arrayToQueryStringArray($parameters);
            $sqlStr.= "AND cc.".CREDIT_CARD_TABLE_FIELD_META_KEY." IN ".$parametersStr;
        }

        $result = self::runQuery($sqlStr, CREDIT_CARD_QUERY_TYPE_SELECT, $prepared_placeholders);

        // Compare the ID field from the shortcode to the IDs of the cards being retrieved.
        // This is a filter that makes sure only the data from the correct card is retrieved, despite the use
        // of wildcards to work around arbitrary HTML-encoded characters

        // Turn cardId and feedx_custom_brand_name fields into arrays, where the words are separated by spaces
        // a correct match (ID vs result set) will have exactly the same words and placeholders in exactly
        // the same order

        // Account for case-sensitivity issues
        $cardId_as_array = explode(" ", $cardId);
        $cardId_as_array = array_map('strtolower', $cardId_as_array);
        foreach( $result as $row=>$fields ) {

            $feedx_cbn = explode(" ", $this->wipeAllHTMLSpecialChars(htmlspecialchars_decode($fields[FEEDX_UNIQUE_NAME_FIELD]), '%%'));
            $feedx_cbn = array_map('strtolower', $feedx_cbn);

            // if the cardId (split array) is not exactly the same as the $feed_cbn (split array), then unset the row
            if( $feedx_cbn !== $cardId_as_array ) {
                unset( $result[ $row ] );
            }
        }
        return $result;
    }


	/**
	 * Retrieve metadata for a credit card by the inner ID.
	 *
	 * @param int $cardInnerId
	 *   (Required) Credit card inner ID.
	 * @param array $metaKeys
	 *   (Optional) The meta keys to retrieve ['key1', 'key2']. By default, returns data for all keys.
	 *
	 * @return array
	 *   Returns a [key] => value array of the meta keys and values.
	 */
	public function getCardMeta( int $cardInnerId, array $metaKeys = [] ) {
		$sqlStr = 'SELECT ' . CREDIT_CARD_TABLE_FIELD_META_KEY . ', ' . CREDIT_CARD_TABLE_FIELD_META_VALUE . ' 
                   FROM ' . CREDIT_CARD_TABLE_NAME . '
                   WHERE ' . CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID . '=' . $cardInnerId;

		// Specific meta key(s) requested. Add a condition to the query.
		if ( ! empty( $metaKeys ) ) {
			$sqlStr .= ' AND ' . CREDIT_CARD_TABLE_FIELD_META_KEY . ' IN ' . self::arrayToQueryStringArray( $metaKeys );
		}

		return array_column( self::runQuery( $sqlStr, CREDIT_CARD_QUERY_TYPE_SELECT ), CREDIT_CARD_TABLE_FIELD_META_VALUE, CREDIT_CARD_TABLE_FIELD_META_KEY );
	}

	/**
	 * Update metadata for a credit card by the inner ID.
	 *
	 * If no value exists for the specified credit card inner ID and metadata key, the metadata will be added.
	 *
	 * @param int $cardInnerId
	 *   (Required) Card inner ID.
	 * @param string $metaKey
	 *   (Required) Metadata key.
	 * @param string $metaValue
	 *   (Required) Metadata value.
	 *
	 * @return int|bool
	 *   Meta ID if the key didn't exist, true on successful update, false on failure.
	 */
	public function updateCardMeta( int $cardInnerId, string $metaKey, string $metaValue = null ) {
		if ( ! $metaKey || ! is_numeric( $cardInnerId ) ) {
			return false;
		}

		global $wpdb;
		
		// Compare existing value to new value.
		$oldValue = self::getCardMeta( $cardInnerId, [ $metaKey ] );
		$metaValue = maybe_serialize( $metaValue );

		// The meta key exists. Update it.
		if ( isset( $oldValue[ $metaKey ] ) ) {
			$oldValue = reset( $oldValue );

			// The old meta value is different.
			if ( $oldValue !== $metaValue ) {
				
				return $wpdb->update( CREDIT_CARD_TABLE_NAME,
									  array( CREDIT_CARD_TABLE_FIELD_META_VALUE => $metaValue),
									  array( CREDIT_CARD_TABLE_FIELD_META_KEY => $metaKey,
										   CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID => $cardInnerId)
									);
				/**				
				
				$sqlStr = 'UPDATE  ' . CREDIT_CARD_TABLE_NAME . '
                           SET ' . CREDIT_CARD_TABLE_FIELD_META_VALUE . '=%s
					       WHERE ' . CREDIT_CARD_TABLE_FIELD_META_KEY . '=%s
					       AND ' . CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID . '=%d
					       LIMIT 1;';

				// Update the value.
				return self::runQuery( $sqlStr, CREDIT_CARD_QUERY_TYPE_UPDATE, [ $metaValue, $metaKey, $cardInnerId ] );
				
				**/
			}

			// No update was needed. The value stays the same.
			return true;
		}

		
		return $wpdb->insert( CREDIT_CARD_TABLE_NAME,
								array(CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID => $cardInnerId,
									  CREDIT_CARD_TABLE_FIELD_META_KEY => $metaKey,
									  CREDIT_CARD_TABLE_FIELD_META_VALUE => $metaValue)
							);
		/**
		// The meta key doesn't exist. Create it.
		$sqlStr = 'INSERT INTO  ' . CREDIT_CARD_TABLE_NAME . '
                           ( ' . CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID . ',' . CREDIT_CARD_TABLE_FIELD_META_KEY . ',' . CREDIT_CARD_TABLE_FIELD_META_VALUE . ')
                           VALUES (%d, %s, %s);';

		return self::runQuery( $sqlStr, CREDIT_CARD_QUERY_TYPE_INSERT, [ $cardInnerId, $metaKey, $metaValue ] );
		**/
	}

    /**
     * @param $value
     * @return string
     *
     * Helper functions for writing SQL
     */
    private function valueToQueryStr($value){
            return " '" . $value . "' ";
    }
    private function talbeFieldToQueryStr($tableName, $tableField){
        return " ".$tableName . "." . $tableField ." ";
    }
    private function arrayToQueryStringArray($arr){
        return  "('" . implode ("','", $arr) . "')";
    }


    /**
     *  Create credit card table
     */
    private function getSql_createCreditCardsTable($prefix, $charset_collate) {

        $table_name = TABLE_CREDIT_CARDS;        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
              id mediumint(9) NOT NULL AUTO_INCREMENT,
              ".CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID."  mediumint(9) NOT NULL,
              ".CREDIT_CARD_TABLE_FIELD_META_KEY." text NOT NULL,                            
              ".CREDIT_CARD_TABLE_FIELD_META_VALUE." text NOT NULL,                            
              ".CREDIT_CARD_TABLE_FIELD_TIME_CREATION." TIMESTAMP DEFAULT CURRENT_TIMESTAMP,              
              PRIMARY KEY  (id)
            ) $charset_collate;";

        return  $sql ;

    }

    /**
     * @param $prefix
     * @param $charset_collate
     * @return string
     *
     * writes SQL for creating credit card version table
     */
    private function getSql_createCreditCardVersionTable($prefix, $charset_collate){

        $table_name = CREDIT_CARD_VERSIONS_TABLE_NAME;
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID." mediumint(9) NOT NULL AUTO_INCREMENT,
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME."  text NOT NULL,
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." text NOT NULL,                            
			  ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME." text NOT NULL,   
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." text NOT NULL,                            
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE." text,
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_TIME_CREATION." TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  
              ".CREDIT_CARD_VERSIONS_TABLE_FIELD_TIME." TIMESTAMP DEFAULT CURRENT_TIMESTAMP,           
              PRIMARY KEY  (".CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID.")
            ) $charset_collate;";
        return $sql;    
      
    }

    /**
     * @param $prefix
     * @param $charset_collate
     * @return string
     *
     * Create User to token table
     */
    private function getSql_createCreditCardUserToTokenTable($prefix, $charset_collate){
        $table_name = CREDIT_CARD_TOKENS_TABLE_NAME;

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
              ".CREDIT_CARD_TOKENS_TABLE_FIELD_AUTO_ID." mediumint(9) NOT NULL AUTO_INCREMENT,  
              ".CREDIT_CARD_TOKENS_TABLE_FIELD_USER_ID."  mediumint(9) NOT NULL,           
              ".CREDIT_CARD_TOKENS_TABLE_FIELD_TOKEN." BIGTEXT NOT NULL,
              ".CREDIT_CARD_TOKENS_TABLE_FIELD_TIME_CREATION." TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                           
              PRIMARY KEY  (".CREDIT_CARD_TOKENS_TABLE_FIELD_AUTO_ID.")
            ) $charset_collate;";
        return $sql;
    }

    /**
     * @param $settingName
     * @return string
     *
     * Get credit card settings
     */
	private function getCreditCardSettings($settingName){
        $settings = get_option(WP_OPTIONS_CREDIT_CARD_SETTINGS);

        $setting = !empty($settings) ? $settings[$settingName] : '';
        return $setting;
    }

    /**
     * @param $config
     *
     * Remove outdated card versions
     */
    public function removeOldCardVersion($config){

        $maxAllowedVersionsPerAdvertiser = $this->getCreditCardSettings(REQUEST_PARAM_MAX_VERSION_COUNT_PER_ADVERTISER);
        $maxAllowedVersionsPerAdvertiser = empty($maxAllowedVersionsPerAdvertiser)
            ? CREDIT_CARD_DEFAULT_MAX_VERSION_COUNT_PER_ADVERTISER
            : $maxAllowedVersionsPerAdvertiser;

        $shouldRemoveOldCardVersion = $this->verifyShouldRemoveOldCardVersion($config, $maxAllowedVersionsPerAdvertiser);
        if ($shouldRemoveOldCardVersion){
            $this->deleteOldCards($config);
        }

    }

    /**
     * @param $config
     * @return bool
     *
     * Verify that issuing bank is in the database
     */
    private function verifyAdvertiserCardVersionExists($config){

        $sqlStr = "SELECT ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION."
                    FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME."
                    WHERE  ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." LIKE ". $this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]).
                    " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." LIKE ". $this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION]).
            "GROUP BY ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION;

        $result = $this->runQuery($sqlStr);

        $isAdvertiserCardVersionExists = !empty($result) ? true : false;

        return $isAdvertiserCardVersionExists;
    }
    /**
     * Mothod check if there are more or equal card versions.
     * If there are maximum allowed versions, return true,
     * else return false.
     *
     * @param $config
     * @return bool
     */
    private function verifyShouldRemoveOldCardVersion($config, $maxAllowedVersionsPerAdvertiser = CREDIT_CARD_DEFAULT_MAX_VERSION_COUNT_PER_ADVERTISER){

        $shouldRemoveOldCardVersion = false;
        $sqlStr = "SELECT ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION."
                    FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME."
                    WHERE  ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." LIKE ".
                    $this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]).
                    "GROUP BY ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION;

        $result = $this->runQuery($sqlStr);

        $isAdvertiserCardExists = $this->verifyAdvertiserCardVersionExists($config);
        // verify that there are no more than $maxAllowedVersionsPerAdvertiser cards at the database
        // and verify that the version in $config does not exists at the database.

        if (count($result) >= $maxAllowedVersionsPerAdvertiser && !$isAdvertiserCardExists){
            $shouldRemoveOldCardVersion = true;
        }

        return $shouldRemoveOldCardVersion;
    }

    /**
     * @param $config
     *
     * Delete old cards from all FeedX tables
     */
    private function deleteOldCards($config){

        // select the oldest cards version of the advertiser
        $sqlStr = "SELECT ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION.", ".CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID.
                    " FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                    " WHERE  ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." LIKE ".$this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]).
                    " AND ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION.
                    " = (SELECT Min(".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION.") FROM ".
                    CREDIT_CARD_VERSIONS_TABLE_NAME.
                    " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID." LIKE ".$this->valueToQueryStr($config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]).")
                    GROUP BY ".CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION." , ".CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID;

        $result = $this->runQuery($sqlStr);
		
		// extract "innerId" fields from all out-of-date cards, to be passed to the DELETE action
        $innerIdsArr = array_map(
            function($c) {
                return $c[CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID];
            },
            $result
        );

        $this->deleteCardsByInnerIdFromCardsTable($innerIdsArr);
        $this->deleteCardsByInnerIdFromVersionTable($innerIdsArr);

    }

    /**
     * @param $cardsDelationInfo
     * @return array|int|null|object|string
     *
     * Delete cards from each individual table (helps the main "delete old cards" function above.
     *
     */
    private function deleteCardsByInnerIdFromVersionTable($cardsDelationInfo){
        $sqlStr = "DELETE FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME.
                " WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID. " IN ".
            $this->arrayToQueryStringArray($cardsDelationInfo);

        $result = $this->runQuery($sqlStr);

        return $result;
    }
    private function deleteCardsByInnerIdFromCardsTable($cardsDelationInfo){

        $sqlStr = "DELETE FROM ".CREDIT_CARD_TABLE_NAME.
                " WHERE ".CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID. " IN ".
                $this->arrayToQueryStringArray($cardsDelationInfo);

        $result = $this->runQuery($sqlStr);

        return $result;
    }
    private function generateUpdateTokenQueryStr($userId, $token){

        $sqlStr = "UPDATE ".CREDIT_CARD_TOKENS_TABLE_NAME.
            " SET ".
            CREDIT_CARD_TOKENS_TABLE_FIELD_TOKEN."=".$this->valueToQueryStr($token).",".
            CREDIT_CARD_TOKENS_TABLE_FIELD_TIME_CREATION."=CURRENT_TIMESTAMP".
            " WHERE ".CREDIT_CARD_TOKENS_TABLE_FIELD_USER_ID." LIKE ".$this->valueToQueryStr($userId);


        return $sqlStr;
    }

    /**
     * @param $userId
     * @param $token
     * @return string
     *
     * Generate insert token query string
     */
    private function generateInsertTokenQueryStr($userId, $token){

        $sqlStr = "INSERT INTO ".CREDIT_CARD_TOKENS_TABLE_NAME." (`" .
            CREDIT_CARD_TOKENS_TABLE_FIELD_USER_ID."`, `".
            CREDIT_CARD_TOKENS_TABLE_FIELD_TOKEN."`, `".
            CREDIT_CARD_TOKENS_TABLE_FIELD_TIME_CREATION."`) 
                   VALUES ('".$userId."', '".$token."', CURRENT_DATE())";

        return $sqlStr;
    }

    /**
     * method gets $userId and $token and write them into table
     * CREDIT_CARD_TOKENS_TABLE_NAME, if user not exists in the talbe, add it with the token,
     * if the user already exists , update the user id with the new token
     *
     * @param $userId
     * @param $token
     * @return array|int|null|object|string
     */
    public function addUserToken($userId, $token){

        $sqlStr = "SELECT * FROM ".CREDIT_CARD_TOKENS_TABLE_NAME  .
            " WHERE ".CREDIT_CARD_TOKENS_TABLE_FIELD_USER_ID ."=".$this->valueToQueryStr($userId);
        $result = $this->runQuery($sqlStr);
        if (!empty($result)){ // update existing user token
            $sqlStr = $this->generateUpdateTokenQueryStr($userId, $token);
            $result = $this->runQuery($sqlStr, CREDIT_CARD_QUERY_TYPE_INSERT);
        }else{// create new record with user and token
            $sqlStr  = $this->generateInsertTokenQueryStr($userId, $token);
            $result = $this->runQuery($sqlStr);
        }
        return $result;
    }

    /**
     * @param $token
     * @return array|int|null|object|string
     *
     * Find token by ID
     */
    public function findToken($token){
        $sqlStr = "SELECT * FROM ".CREDIT_CARD_TOKENS_TABLE_NAME.
            " WHERE ".CREDIT_CARD_TOKENS_TABLE_FIELD_TOKEN ."=".$this->valueToQueryStr($token);

        $result = $this->runQuery($sqlStr);

        return $result;
    }

    /**
     * @param $cards
     * @param $config
     *
     * Update the ACF fields for brands that already have cards assigned to them
     * unchecks the 'credit_card_na_from_feedx' field (ACF) for all the brands
     */
    private function updateCardsMatchedToBrands( $cards, $config ) {

        // reorganize cards, to be found by bank+brand name
        $new_array_of_cards = array();
        foreach( $cards as $card ) {
			$new_array_of_cards[ $config[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID]."--".$this->wipeAllHTMLSpecialChars($card[FEEDX_UNIQUE_NAME_FIELD]) ] = $card;
        }

        // get the Palcon brands
        $brands = $this->getAllBrandsWithCards();

        // if there are no brands (either because it's not a Palcon site, or nobody matched any cards yet)
        // then there's nothing further to do
        if( ! empty($brands) ) {

            // match Palcon brands to their card data
            foreach ($brands as $key => $brand) {
                $brands[$key]['card_data'] = $new_array_of_cards[$brand['bank_id'] . "--" . $this->wipeAllHTMLSpecialChars($brand['card_name'])];
            }
            // update each brand's meta fields
            foreach ($brands as $brand) {
				
				if( ! empty($brand['card_data']) ) {
					foreach ($brand['card_data'] as $key => $value) {
						
						// update brand data
						update_post_meta($brand['id'], $key, $value);
					}
                    update_post_meta($brand['id'], CREDIT_CARD_N_A_FROM_FEEDX, 0);
                }
            }
			
			// update LinkSets if applicable
			$this->updateLinkSets($brands);
			
			// update all posts containing Schumer Table widgets, or other widgets displaying credit card data.
			$this->updatePostsDisplayingCreditCardData( $cards );

			
        }
    }

    /**
     * flag brand objects whose associated card was removed from feedx using the 'credit_card_na_from_feedx' ACF(meta_key) checkbox
     */
    public function handleRemovedCards(){
        $noAssociatedCardBrandsIds = $this->getNoAssociatedCardBrandsIds();
        foreach ($noAssociatedCardBrandsIds as $brandIdToFlag){
            update_post_meta($brandIdToFlag, CREDIT_CARD_N_A_FROM_FEEDX, 1);
        }
    }

    /**
     * get an array of post id's of all the brand object whose associated cards were removed from feedx
     *
     * @return array - array of post id's of all the brand object whose associated cards were removed from feedx
     */
    public function getNoAssociatedCardBrandsIds(){
        $noAssociatedCardBrandsIds = [];

        global $wpdb;
        $query = "SELECT ".FEEDX_BRAND_POST_ID." FROM $wpdb->postmeta 
                  WHERE ".CREDIT_CARD_TABLE_FIELD_META_KEY."=%s
                  AND ".CREDIT_CARD_TABLE_FIELD_META_VALUE." NOT IN (SELECT ".FEEDX_UNIQUE_NAME_FIELD." FROM ".CREDIT_CARD_VERSIONS_TABLE_NAME." WHERE ".CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE." = %s)";
        $prepared_array = array(FEEDX_UNIQUE_NAME_FIELD, CREDIT_CARD_STATUS_ACTIVE);
        $tempArray = $this->runQuery( $query, $queryType = CREDIT_CARD_QUERY_TYPE_SELECT, $prepared_array);

        foreach ($tempArray as $element){
            $noAssociatedCardBrandsIds[] = $element[FEEDX_BRAND_POST_ID];
        }

        return $noAssociatedCardBrandsIds;
    }

    /**
     * @return array|int|null|object|string
     *
     * Helper function that gets all brands with assigned FeedX cards.
     */
    private function getAllBrandsWithCards() {

        // query the brands with cards already matched to them
        global $table_prefix;

        $query = "SELECT post.id AS id, post.post_name AS post_name, bank.meta_value AS bank_id, card.meta_value AS card_name ".
            "FROM ".$table_prefix."postmeta card INNER JOIN ".$table_prefix."postmeta bank ON bank.post_id = card.post_id ".
            "INNER JOIN ".$table_prefix."posts post ON post.id = card.post_id AND post.post_type = 'brand' ".
            "WHERE bank.meta_key = %s AND card.meta_key = %s ";
        $prepared_array = array(FEEDX_BRAND_BANK_KEY, FEEDX_BRAND_CARD_KEY);

        $brands = $this->runQuery( $query, CREDIT_CARD_QUERY_TYPE_SELECT, $prepared_array);

        return $brands;
    }
	/**
	 * Fixes a bug where card names won't match because of HTML encoding problems.
	 * Solution is to remove all of that weirdness.
	 * Source: https://stackoverflow.com/questions/7128856/strip-out-html-and-special-characters
	 */
	private function wipeAllHTMLSpecialChars( $string, $replace = ' ' ) {
		if( $replace !== ' ' ) {
			return trim(preg_replace('/[^A-Za-z0-9 ]+/', $replace, urldecode(html_entity_decode(strip_tags($string)))));
		} else {
			return trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($string))))));
		}
	}
	
	/**
	 * Found this on stackoverflow.
	 * Am using it to create "pretty URLs" for linksets that don't exist yet
	 */
	private function slugify($text) {
		
	  $text = wipeAllHTMLSpecialChars($text);
	  // replace non letter or digits by -
	  $text = preg_replace('~[^\pL\d]+~u', '-', $text);

	  // transliterate
	  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

	  // remove unwanted characters
	  $text = preg_replace('~[^-\w]+~', '', $text);

	  // trim
	  $text = trim($text, '-');

	  // remove duplicate -
	  $text = preg_replace('~-+~', '-', $text);

	  // lowercase
	  $text = strtolower($text);

	  if (empty($text)) {
		return 'n-a';
	  }

	  return $text;
	}


    /**
     * @param $brand_data
     *
     * All LinkSets operations happen here
     */
	private function updateLinkSets( $brand_data ) {
		
		// this function relies on WCMSLinkSets2. If it's not available, or if methods that I need are not defined, then stop this process now
		if( ! (is_plugin_active("wcms_link_sets_2/wcms_link_sets_2.php") && method_exists("WCMSLinkSets2", "get_default_links_by_brand_ids") ) ) {
			return;
		}
		
		// 1. Find the corresponding brand ID to the credit card (see function params)
		// 2. Query the wp_default_links_sets for "`brand_id`=[id] AND `is_default`=1" => Gets you the main default link for the brand to make sure you have the required records to update and keep the row to use for updating queries.
		$results = $this->getLinkSetsDefaultData( $brand_data );
		$brand_data = $this->attachLinkSetsDataToBrands($brand_data, $results);

		// IGNORE STEPS 4 AND 5. WE DON'T ACTUALLY NEED A TRACKER_ID FOR THIS TASK.
		// 3. Get the Tracker ID from palsys using _wcmsls2_get_tracker_ids($urls: string[]) in wp-content\plugins\wcms_link_sets_2\wcms_link_sets_2.php (or the error message).
		// 4. Add a public function to wcms_link_sets_2.php that wraps _wcmsls2_get_tracker_ids.

		// Steps 5 and 6 are in here
		$this->updateLinkSetsDatabaseAction( $brand_data );
		
	}

    /**
     * @param $brand_data
     * @return mixed
     *
     * Helper function that pulls LinkSets data for the selected brands
     */
	private function getLinkSetsDefaultData( $brand_data ) {
		$array_of_ids = array();
		foreach( $brand_data as $brand ) {
			$array_of_ids[] = $brand['id'];
		}
		$linksets = WCMSLinkSets2::init();
		return $linksets->get_default_links_by_brand_ids($array_of_ids);
	}

    /**
     * @param $brand_data
     * @param $results
     * @return mixed
     *
     * Attach the linksets data (returned by getLinkSetsDefaultData() ) to brand data sets, and return the brands.
     */
	private function attachLinkSetsDataToBrands( $brand_data, $results ) {
		if( ! empty( $results ) ) {
			foreach( $results as $result ) {
				foreach( $brand_data as $key => $val ) {
					if($brand_data[$key]['id'] == $result['brand_id']) {
						$brand_data[$key]['linksets_data'] = $result;
						continue;
					}
				}
				
			}
		}
		return $brand_data;
	}

    /**
     * @param $brand_data
     *
     * All updates to LinkSets (Defaults, and History) happens here
     */
	private function updateLinkSetsDatabaseAction( $brand_data ) {
		
		// call these outside of the loop, so that there's no memory wasted on duplicate/overwritten instances
		$linksets = WCMSLinkSets2::init();
		$links_to_insert = array();
		$links_to_update = array();
		
		// DEBUG
		error_log( __FUNCTION__ ."(): Beginning to update LinkSets.");
		
		
		// 5. Update wp_default_links_sets table for the brand with the new affiliate URL (tracker) and tracker id (tracker_id) for each link (using id_ls).
		foreach( $brand_data as $key => $data ) {
			
			
			// 6. Create new row in wp_wcmsls_history for each link you've updated
			if( !empty( $data['card_data'] ) && ! empty($data['linksets_data']) ) {
				
				// DO NOT UPDATE LINKSETS IF THE TRACKING LINK HAS NOT CHANGED
				// That would just be silly
				if( trim( $data['card_data']['feedx_brand_tracking_link'] ) !== trim( $data['linksets_data']['tracker'] ) ) {
					
					// first, set all previous links to "not default", and "not active"
					$linksets->reset_defaults_for_linksets_by_brand($brand_data[$key]['id']);
								  
					// insert the new link --> UPDATE, NOT INSERT
					$links_to_update[] = array('brand_id' => $brand_data[$key]['id'], 
											'id_ls' => $brand_data[$key]['linksets_data']['id_ls'],
										
											// if the existing "pretty_link" is the default, broken (to prevent even worse breaks) value, attempt to fix it.
										  'pretty_link' => "links/".$brand_data[$key]['post_name'],
															
										  'tracker_id' => "", //<<PALSYS_TRACKER>> ,
										  'tracker' => $brand_data[$key]['card_data']['feedx_brand_tracking_link'],
										  'is_default' => 1,
										  'active' => 1,
										  'sub_id' => $brand_data[$key]['linksets_data']['sub_id'],
										  'sub_id_parameter' => $brand_data[$key]['linksets_data']['sub_id_parameter'],
										  'category_id' => null);
				}
			} else if( !empty( $data['card_data'] ) && empty($data['linksets_data']) ) {	// New brand, setting up its first Linksets record
				error_log( __FUNCTION__ ."(): Inserting new link (".brand_data[$key]['id'].").");
			
				$links_to_insert[] = array('brand_id' => $brand_data[$key]['id'], 
										  'pretty_link' => "links/".$brand_data[$key]['post_name'],
										  'tracker_id' => "", //<<PALSYS_TRACKER>> ,
										  'tracker' => $brand_data[$key]['card_data']['feedx_brand_tracking_link'],
										  'is_default' => 1,
										  'active' => 1,
										  'sub_id' => "", //$brand_data[$key]['linksets_data']['sub_id'],
										  'sub_id_parameter' => "", //$brand_data[$key]['linksets_data']['sub_id_parameter'],
										  'category_id' => null);
				
			}
		}

		if( ! empty( $links_to_update ) ) {
			$linksets->public_wcmsls2_update_links_in_ls($links_to_update);
		}
		
		$inserted_links = $linksets->public_wcmsls2_insert_new_links_to_ls($links_to_insert);
		
		
		foreach($brand_data as $key => $data) {
			if( ! empty( $inserted_links ) ) {
				foreach($inserted_links as $k => $v) {
					if($brand_data[$key]['id'] == $v['brand_id'] ) {
						$brand_data[$key]['id_ls'] = $v['id_ls'];
						continue;
					}
				}
			}

			// only update card history if there is new data to update.
			if( !empty( $data['card_data'] ) &&
                trim( $data['card_data']['feedx_brand_tracking_link'] ) !== trim( $data['linksets_data']['tracker'] )
                                                ) {	// ['card_data'] is only populated by data from the latest push from FEEDX.
													// All other cards are ignored, even though we pulled their data earlier.
				error_log( __FUNCTION__ ."() Attempting to update LinkSets History for ".$brand_data[$key]['id']."...." );
				$this->updateLinkSetsHistory($brand_data[$key]);
			}
		}
	}

    /**
     * @param $brand_data
     *
     * Update the linksets history
     */
	private function updateLinkSetsHistory($brand_data ) {
		
		// This is the structure that Vlad said it's supposed to look like:
		$new_link_for_history = array(
	
			"id_ls" => ( isset($brand_data["id_ls"]) ? $brand_data["id_ls"] : $brand_data['linksets_data']['id_ls']), //$id_of_last_insert,
			"active" => 1,
			"pretty_link" => $brand_data['linksets_data']["pretty_link"],
			"is_default" => 1,
			"tracker" => $brand_data['card_data']['feedx_brand_tracking_link'],
			"category_id" => $brand_data['linksets_data']['category_id'],
			"category_name" => 'Uncategorized',
			"brand_id" => $brand_data['id'],
			"brand_name" => $brand_data['card_data']['feedx_brand_name'],
			"tracker_id" => "", //$palsys_tracker_id,		// we're not using PalSys for this
			"sub_id" => 1,
		//	"sub_id_parameter" => '', //this is set manually, by the user
		
			"original_link" => array (
				"id_ls" =>  $brand_data['linksets_data']['id_ls'],
				"active" => 0,
				"pretty_link" =>  $brand_data['linksets_data']["pretty_link"],
				"is_default" => 0,
				"tracker" =>  $brand_data['linksets_data']['tracker'],
				"category_id" =>  $brand_data['linksets_data']['category_id'],
				"category_name" => 'Uncategorized',
				"brand_id" =>  $brand_data['id'],
				"brand_name" =>  $brand_data['card_data']['feedx_brand_name'],
				"tracker_id" =>  $brand_data['linksets_data']['tracker_id'],
				"sub_id" => 0,
				"sub_id_parameter" => $brand_data['linksets_data']['sub_id_parameter']
		));
		$linksets_instance = $linksets = WCMSLinkSets2::init();
		$linksets_instance->public_wcmsls2_insert_links_to_ls_history(array( $new_link_for_history ) , 'default');
	}
	
	/**
	 * @param $cards
	 *
	 * Using the list of cards received from FeedX, find all of the posts and pages that display credit card data (e.g. pages containing Schumer Table widgets)
	 * and set their "post_modified" field to NOW()
	 ***/
	private function updatePostsDisplayingCreditCardData( $cards ) {
	
		// don't bother, if the required dependency is not active
		if ( ! is_plugin_active( 'wcms_widgets/wcms_widgets.php' ) ){
			return;
		}

		// import WP database
		global $wpdb;

		// array which stores a list of the widget types that we are searching, 
		// the field for identifying which cards are assigned to instances of these widgets
		// and eventually a list of widget-id => card-id pairs by widget type
		$widget_types = array( 
							  "schumer-box" => array("card_field" => "general_choose_brand")
							  //"widget-2" => array("card_field" => "field_whatever")
						  );
						  
		// build the set of queries (combined via UNION) for finding all widgets with assigned cards
		$query = "";
		$widget_counter = 1;
		foreach( $widget_types as $type => $data ) {
			$query .= 	'SELECT widget.post_id, widget.meta_key AS tabletype, widget.meta_value AS widgettype, pivot.meta_value AS brandid, brand.meta_value AS carduniquename
						 FROM '.$wpdb->postmeta.' widget 
						 INNER JOIN '.$wpdb->postmeta.' pivot ON pivot.post_id = widget.post_id AND pivot.meta_key = "'.$data["card_field"].'"
						 INNER JOIN '.$wpdb->postmeta.' brand ON brand.post_id = pivot.meta_value AND brand.meta_key = "feedx_card_name"
						 INNER JOIN '.$wpdb->posts.' p ON widget.post_id = p.id AND p.post_status = "publish"
						 WHERE p.post_type IN ("conversion_table", "navigation_elements")
							AND widget.meta_key = "table_type"
							AND widget.meta_value = "'.$type.'" ';
			
			if( $widget_counter < count($widget_types) ) {
				$query .= " UNION ";
			}
			$widget_counter++;
		}
		// run the query		  
		$all_card_widgets = $wpdb->get_results($query, ARRAY_A);

		// reduce the list to only include the widgets whose cards were updated
		
		$list_of_cards_updated_by_feedx = array_map(function ($i) { return $i['feedx_custom_brand_name']; }, $cards);
		$list_of_widget_ids_with_updated_cards = array();
		foreach( $all_card_widgets as $key => $row ) {
			if( ! in_array($row['carduniquename'], $list_of_cards_updated_by_feedx ) ) {
				unset( $all_card_widgets[$key] );
			} else {
				$list_of_widget_ids_with_updated_cards[] = $row['post_id'];
			}
		}

		// get a list of POST IDs whose "post_modified" fields need to be updated
		// find-widget-pages function to be imported from wcms_widgets/functions.php
		$list_of_posts_to_update = $this->get_posts_containing_schumer_tables($list_of_widget_ids_with_updated_cards);

		// update all posts in the list
		$wpdb->query('UPDATE '.$wpdb->posts.' SET post_modified = NOW() WHERE id IN ('.implode(",",$list_of_posts_to_update).')' );
	}
	
	/**
	 *	Query the database, to find all posts containing the specified widgets.
	 *
	 *	Return the posts' IDs.
	 */
	private function get_posts_containing_schumer_tables($widget_id_list) {
		
        global $wpdb;
        $wp_posts = $wpdb->posts;
        $wp_postmeta = $wpdb->postmeta;

        $post_types = "('page','promotions','tips','news','story','odds_event','odds_match','events', 'review-post-1', 'review-post-2', 'brand-review', 'brand-review-light')";
        $widget_types = "('conversion_table','navigation_elements','graphical_widgets')";

        // ACF Widgets
        $query = "SELECT DISTINCT `ID` AS 'post_id', `post_title` AS 'title'
                  FROM `$wp_postmeta`
                  INNER JOIN `$wp_posts` ON `$wp_postmeta`.`post_id`=`$wp_posts`.`ID`
                  WHERE `$wp_posts`.`post_status` IN ('publish', 'inherit')
                  AND `$wp_posts`.`post_type` IN $post_types
                  AND `$wp_postmeta`.`meta_value` IN (
                      SELECT `$wp_posts`.`ID`
                      FROM `$wp_posts`
                      WHERE `$wp_posts`.`post_type` IN $widget_types
                      AND `$wp_posts`.`ID` IN (".implode(",",$widget_id_list).")
                  )";
				  
        $acf_results = $wpdb->get_results($query, "ARRAY_A");

        // Shortcode widgets
        //implode("|",$widget_id_list)
        $regexp_string = "'[[]wcms_widget widgetid=\\'?".  ( count($widget_id_list) > 1 ? "(".implode("|",$widget_id_list).")" : $widget_id_list[0])  ."\\'?[]]'";
        $query = "SELECT DISTINCT `$wp_postmeta`.`post_id` AS 'post_id', `$wp_posts`.`post_title` AS 'title'
                  FROM `$wp_postmeta`
                  INNER JOIN `$wp_posts` ON `$wp_postmeta`.`post_id`=`$wp_posts`.`ID`
                  WHERE `$wp_postmeta`.`meta_value` REGEXP $regexp_string
                  AND `$wp_posts`.`post_status` IN ('publish', 'inherit')
                  AND `$wp_posts`.`post_type` IN $post_types";

		$shortcode_results = $wpdb->get_results($query, "ARRAY_A");
		
        $results = array_merge($acf_results, $shortcode_results);
		
		// return the post IDs of the relevant posts
        $processed_page_ids = array();

        foreach ($results as $result) {
            $page_post_id = $result['post_id'];
			$processed_page_ids[] = $page_post_id;
        }
		// Prevent duplicates
		return array_unique($processed_page_ids);
    }
}
