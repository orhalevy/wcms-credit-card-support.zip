<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

class CreditCardsRestServer extends WP_REST_Controller {
 

var $my_namespace = 'wp';
var $api_version   = '/v2/';

  function __construct(){
    require_once(dirname(__FILE__) . '/../classes/WcmsCreditCardDatabaseHandler.php');
      do_action('JWT_AUTH_EXPIRE', $arg = time());

  }

    /**
     *
     */
  public function register_routes() {
    
    $namespace = $this->my_namespace . $this->api_version;
    $base      = 'cards_rest_server';
    register_rest_route( $namespace, '/' . $base, array(
          array(
              'methods'         => WP_REST_Server::CREATABLE,
              'callback'        => array( $this, 'handleCreditCardsPostRequests' ),
              'permission_callback'   => array( $this, 'handleCreditCardsPostPermissions' )
            )
    ));
  }
 
  // Register our credit cards REST Server
  public function hookRestServer(){
    add_action( 'rest_api_init', array( $this, 'register_routes' ) );
  }

    /**
     * @param $type
     * @param array $responseRes
     * @return array
     */
  private function generateResponse($type, $responseRes = array()){

      $isSuccess = $responseRes[RESPONSE_OBJ_KEY_RESULT];
      $isAdvertiserCardsVersionExists = !empty($responseRes[RESPONSE_OBJ_KEY_VERSION_EXISTS])
          ? $responseRes[RESPONSE_OBJ_KEY_VERSION_EXISTS]
          : '';

    switch ($type){
        case REQUEST_SUB_TYPE_UPDATE_SCHEMA :
           $responseMsg = $this->generateUpdateSchemaResponse($isSuccess);
           break;
        case REQUEST_SUB_TYPE_ADD_NEW_CARDS :
            if ($isAdvertiserCardsVersionExists){
                $responseMsg = $this->generateAddNewCardsAdvertiserVersionExistsResponse($isAdvertiserCardsVersionExists);
            }else{
                $responseMsg = $this->generateAddNewCardsResponse($isSuccess);
            }
            break;
        case REQUEST_SUB_TYPE_UPDATE_CARDS_VERSION :
            if ($isAdvertiserCardsVersionExists){
                $responseMsg = $this->generateUpdateCardsVersion($isSuccess);
            }else {
                $responseMsg = $this->generateAddNewCardsAdvertiserVersionExistsResponse($isAdvertiserCardsVersionExists);
            }
            break;
        case REQUEST_SUB_TYPE_UPDATE_CONFIG_SETTINGS :
            $responseMsg = $this->generateConfigResponse($isSuccess);
            break;
        default :
          $responseMsg = $this->generateDefaultResponse($isSuccess);
    
    }

    return $responseMsg;
  }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateConfigResponse($isSuccess){
      if ($isSuccess){
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_CONFIG_SETTINGS_SUCCESS,
              RESPONSE_MSG => RESPONSE_STATUS_CONFIG_SETTINGS_MSG_SUCCESS
          );
      }else{
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_CONFIG_SETTINGS_FAILED,
              RESPONSE_MSG => RESPONSE_STATUS_CONFIG_SETTINGS_MSG_FAILED
          );
      }

      return $responseMsg;
  }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateAddNewCardsResponse($isSuccess){
      if ($isSuccess){
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_ADD_NEW_CARDS_SUCCESS,
              RESPONSE_MSG => RESPONSE_STATUS_ADD_NEW_CARDS_MSG_SUCCESS
          );
      }else{
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_ADD_NEW_CARDS_FAILED,
              RESPONSE_MSG => RESPONSE_STATUS_ADD_NEW_CARDS_MSG_FAILED
          );
      }

      return $responseMsg;
  }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateAddNewCardsAdvertiserVersionExistsResponse($isSuccess){

            if($isSuccess){
                $responseMsg = array(
                    RESPONSE_CODE => RESPONSE_STATUS_CARDS_EXISTS,
                    RESPONSE_MSG => RESPONSE_STATUS_CARDS_MSG_EXISTS
                );
            }else{
                $responseMsg = array(
                    RESPONSE_CODE => RESPONSE_STATUS_CARDS_NOT_EXISTS,
                    RESPONSE_MSG => RESPONSE_STATUS_CARDS_MSG_NOT_EXISTS
                );
            }

        return $responseMsg;
    }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateUpdateSchemaResponse($isSuccess){
    if ($isSuccess){
      $responseMsg = array(
        RESPONSE_CODE => RESPONSE_STATUS_SCHEMA_UPDATE_SUCCESS,
        RESPONSE_MSG => RESPONSE_STATUS_SCHEMA_UPDATE_MSG_SUCCESS
      );
    }else{
      $responseMsg = array(
        RESPONSE_CODE => RESPONSE_STATUS_SCHEMA_UPDATE_FAILED,
        RESPONSE_MSG => RESPONSE_STATUS_SCHEMA_UPDATE_MSG_FAILED
      );
    }

    return $responseMsg;
  }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateUpdateCardsVersion($isSuccess){
      if ($isSuccess){
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_CARDS_VERSION_UPDATE_SUCCESS,
              RESPONSE_MSG => RESPONSE_STATUS_CARDS_VERSION_UPDATE_MSG_SUCCESS
          );
      }else{
          $responseMsg = array(
              RESPONSE_CODE => RESPONSE_STATUS_CARDS_VERSION_UPDATE_FAILED,
              RESPONSE_MSG => RESPONSE_STATUS_CARDS_VERSION_UPDATE_MSG_FAILED
          );
      }

      return $responseMsg;
  }

    /**
     * @param $isSuccess
     * @return array
     */
  private function generateDefaultResponse($isSuccess){

    if ($isSuccess){
      $responseMsg = array(
        RESPONSE_CODE => RESPONSE_STATUS_SUCCESS,
        RESPONSE_MSG => RESPONSE_STATUS_MSG_SUCCESS
      );
    }else{
      $responseMsg = array(
        RESPONSE_CODE => RESPONSE_STATUS_FAILED,
        RESPONSE_MSG => RESPONSE_STATUS_MSG_FAILED
      );
    }

    return $responseMsg;
  }

    /**
     * @param $request
     * @return bool
     */
  public function handleCreditCardsPostPermissions($request){
	$jwt = new Jwt_Auth_Public("JWT Authentication for WP-API", 1);
	$response = $jwt->validate_token();
	
	
	return true;
	/*
	if( $response instanceof WP_Error ) {
		return false;
	} else return true;
	*/
	
  }

    /**
     * @param WP_REST_Request $request
     * @return array
     */
  public function handleCreditCardsPostRequests(WP_REST_Request $request){

      $result = $this->generateResponse(RESPONSE_STATUS_FAILED, $this->generateResponseObject(false));

      $cardsInfo = "";
	  $handle = $request->get_param( REQUEST_PARAM_CREDIT_CARDS_HANDLE );
	  if( is_array($handle) ) {
		$cardsInfo = $handle;
	  } else {
		$cardsInfo = json_decode($handle, true);
	  }
	  
	  $config = $cardsInfo[REQUEST_PARAM_CONFIG];
      $data = $cardsInfo[REQUEST_PARAM_DATA];
	  
      if (isset($config[REQUEST_PARAM_TYPE]) && isset($config[REQUEST_PARAM_SUB_TYPE])){
      // handle update database
          switch ($config[REQUEST_PARAM_TYPE]){
              case REQUEST_TYPE_UPDATE :
                  $result = $this->handleUpdates($data, $config);
                  break;
              case REQUEST_TYPE_ADD :
                  $result = $this->handleAddCards($data, $config);
                  break;
              default:
          }

    }

    return  $result;
  }

    /**
     * @param $isSuccess
     * @param null $isAdvertiserCardsVersionExists
     * @return array
     */
  private function generateResponseObject($isSuccess, $isAdvertiserCardsVersionExists = null){

      if ($isAdvertiserCardsVersionExists != null){
          $ret =  array(
              RESPONSE_OBJ_KEY_RESULT => $isSuccess,
              RESPONSE_OBJ_KEY_VERSION_EXISTS => $isAdvertiserCardsVersionExists
          );
      }else{
          $ret =  array(
              RESPONSE_OBJ_KEY_RESULT => $isSuccess
          );
      }


      return $ret;
  }

    /**
     * @param $data
     * @param $config
     * @return array
     */
  private function handleAddCards($data, $config){

      $result = $this->generateResponseObject(false);
      $subType = $config[REQUEST_PARAM_SUB_TYPE];

      switch ($subType){
          case REQUEST_SUB_TYPE_ADD_NEW_CARDS :
              $WCMSCCDBhandler = WcmsCreditCardDatabaseHandler::getInstance();
              $result = $WCMSCCDBhandler->handleCreditCardRequest($data, $config);
              $WCMSCCDBhandler->handleRemovedCards();
              $result = $this->generateResponse(REQUEST_SUB_TYPE_ADD_NEW_CARDS, $result);

              break;
          default:
              $result = $this->generateResponse(RESPONSE_STATUS_FAILED, $result);

      }

      return $result;
  }

    /**
     * @param $data
     * @param $config
     * @return array
     */
  private function handleUpdates($data, $config){

      $subType = $config[REQUEST_PARAM_SUB_TYPE];

      switch ($subType){

          case REQUEST_SUB_TYPE_UPDATE_SCHEMA :
              update_option(WP_OPTIONS_CREDIT_CARD_DATA_KEYS, $data);
              $isSuccess = true;
              $result = $this->generateResponseObject($isSuccess);
              break;
          case REQUEST_SUB_TYPE_UPDATE_CARDS_VERSION :
              $result = WcmsCreditCardDatabaseHandler::getInstance()->handleCreditCardRequest($data, $config);
              break;
          case  REQUEST_SUB_TYPE_UPDATE_CONFIG_SETTINGS :
              update_option(WP_OPTIONS_CREDIT_CARD_SETTINGS, $config);
              $isSuccess = true;
              $result = $this->generateResponseObject($isSuccess);
              break;
          default:
              $isSuccess = false;
              $result = $this->generateResponseObject($isSuccess);
      }
      $result = $this->generateResponse($subType, $result);

     return $result;
  }
}
