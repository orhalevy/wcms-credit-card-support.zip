<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

require_once( dirname(__FILE__) . '/../constants/wcms_credit_cards_globals.php');
require_once( dirname(__FILE__) . '/../api/credit-cards-api.php');

class WcmsCreditCardHandler{


    const SHORTCODE_CREDIT_CARD_VISUAL = "credit_card_visual";
    const SHORTCODE_CREDIT_CARD_DATA = "credit_card_data";
    const WP_OPTIONS_CREDIT_CARD_DATA_KEYS = "wcms_credit_card_data_keys";

    private $creditCardKeys; // array that contains keys of parameters
	private $custom_shortcode_parameters;

    public function __construct($test = false){
		require_once( dirname(__FILE__) . '/../classes/WcmsCreditCardDatabaseHandler.php');

		// this never runs in the live environment, because no values are ever passed to the constructor in the live environment.
        // In the absence of data, this can be set to run in a test environment, using the code and data in the "tests" and "data" directories.
        if ($test === true) {	// keeping this for debugging (running with mock data) purposes only
            // only for tests 
			require_once(dirname(__FILE__) . '/tests/WcmsCreditCardsTests.php');
            $creditCardTester = new WcmsCreditCardsTest();
            $creditCardTester->insertCreditCards();

        }

        // Custom shortcode keys go here.
        $this->custom_shortcode_parameters = [
            "design"              => "",
            "append_query_string" => "",
        ];

        $this->initCreditCardDataKeys();
        $this->registerShortCodes();

    }

    /**
     * method set creditCardKeys with the keys of parameters of the cards
     *
     */
    private function initCreditCardDataKeys(){
		$schema_keys = (array)get_option(self::WP_OPTIONS_CREDIT_CARD_DATA_KEYS);
		$custom_keys = $this->custom_shortcode_parameters;
		
		if( empty($schema_keys) ) {
			$schema_keys = array();
		}
		
        $this->creditCardKeys = array_merge($schema_keys, $custom_keys);
    }

    /**
     * add shortcodes
     *
     */
    public function registerShortCodes(){
        add_shortcode(self::SHORTCODE_CREDIT_CARD_VISUAL, array($this, 'handleVisualCreditCardShortCode'));
        add_shortcode(self::SHORTCODE_CREDIT_CARD_DATA, array($this, 'handleDataCreditCardShortCode'));
    }

    /**
     * This method handles credit card short code
     *
     */
    public function handleVisualCreditCardShortCode($atts){
		
		$bank = false;
        if( isset( $atts['bank']) ) {
            $bank = $atts['bank'];
        }
		
        $atts = shortcode_atts(
            $this->creditCardKeys,
            $atts,
            self::SHORTCODE_CREDIT_CARD_DATA);

        // bugfix -- HTML is weird. If the special characters don't escape correctly (eg "&amp;#174;" instead of "&#174;")
        // this should correct the problem. And even if it renders correctly, and this converts it into a circle-R
        // symbol, then the "wipeAllHTMLSpecialChars()" function will still replace the weirdness with the correct
        // number of wildcards (shouldn't be more than just "%%", even when there's a bunch in a row)
        $atts[FEEDX_UNIQUE_NAME_FIELD] = htmlspecialchars_decode($atts[FEEDX_UNIQUE_NAME_FIELD]);

        $cardData = WcmsCreditCardDatabaseHandler::getInstance()->getCard($atts[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME], $bank);
		
		if( empty( $cardData )) {
            return "";
        }

        // overriding stored card data goes here
        $cardData = $this->overrideCardTrackingURL( $cardData, $atts );

        $html = $this->generateDataCreditCardHtml($cardData, $atts['design']);

        return $html;
    }

    /**
     * This method will handle credit card short code
     *
     */
    public function handleDataCreditCardShortCode($atts){

        // IF no id OR no field to display, then stop trying here.
        if( empty($atts[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME]) ||
            empty($atts['field']) ) {
            return "";
        }
		
        // save the input, so it won't get overwritten later
        $original_atts = $atts;
		
		$bank = false;
        if( isset( $atts['bank']) ) {
            $bank = $atts['bank'];
        }

        $params = !empty($atts[SHORTCODE_PARAMS]) ?
            explode(",",$atts[SHORTCODE_PARAMS]) :
            array();

        // any FeedX fields with values can be passed in this shortcode
        $atts = shortcode_atts(
            $this->creditCardKeys,
            $atts,
            self::SHORTCODE_CREDIT_CARD_DATA);

        if(empty($params)){
            $cardData = WcmsCreditCardDatabaseHandler::getInstance()->getCard($atts[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME], $bank);
        }else{
            $cardData = WcmsCreditCardDatabaseHandler::getInstance()->getCard($atts[CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME], $bank, $params);
        }

        // if there's no card, then return an empty string
        if( empty( $cardData )) {
            return "";
        }

        // override the tracking URL, if the override params are present.
        $cardData = $this->overrideCardTrackingURL( $cardData, $atts );

        // get the data from the specified field
        $raw_field = $this->overrideDisplayFieldsAndGetFinalValue( $cardData, $original_atts['field'] );
        $formatted_output = $this->applyHtmlFormattingToSingleFieldOutput($raw_field, $original_atts);

        return $formatted_output;
    }

    /**
     * This function renders the HTML for the shortcodes.
     *
     * As of right now, there are no specifications for the actual desired
     * output, so instead there is just enough HTML to prove that it works in
     * alpha testing.
     *
     * @param array $cardData
     *   Multidimensional array of credit card meta data.
     *
     * @param string $alt_template
     *   HTML template suffix to use. Defaults to an empty string.
     *   Resulting filename: schumer_table_template_SUFFIX.html
     *
     * @return mixed|string
     */
    private function generateDataCreditCardHtml($cardData, $alt_template) {

        if (empty($cardData)) {
			return "";
		}

		// This is DEMO output. Do not remove this until the shortcode is working as intended.
		// ----------------------------------------------------------------------------------
		$html = ""; //'---Card Html Goes Here---';
//		$cardDataArr = array();
//		foreach($cardData as $key => $cardDataElement){
//			$cardDataArr[$cardDataElement[CREDIT_CARD_TABLE_FIELD_META_KEY]] = $cardDataElement[CREDIT_CARD_TABLE_FIELD_META_VALUE];
//			$html.= "<div><strong>".$cardDataElement[CREDIT_CARD_TABLE_FIELD_META_KEY].":</strong> ".$cardDataArr[$cardDataElement[CREDIT_CARD_TABLE_FIELD_META_KEY]]."</div>";
//		}
		// --------------------------------------- END DEMO -----------------------------------------------
		$TRANSLATION_DOMAIN = "wcms_credit_card_support";
		
		// Populate placeholders array
		// We like TWIG-type madlibs HTML templates, because they make frontend life easier.
		$placeholders = array(
			"show_more" => __("Show More", $TRANSLATION_DOMAIN),
			"show_less" => __("Show Less", $TRANSLATION_DOMAIN)
		);
		foreach($cardData as $key => $cardDataElement) {
			$placeholders[$cardDataElement[CREDIT_CARD_TABLE_FIELD_META_KEY]] = (
			    empty($cardDataElement[CREDIT_CARD_TABLE_FIELD_META_VALUE]) &&
                    ! is_numeric($cardDataElement[CREDIT_CARD_TABLE_FIELD_META_VALUE]) ?
                "N/A" : $cardDataElement[CREDIT_CARD_TABLE_FIELD_META_VALUE]);
		}


		$dir = dirname(__FILE__);
		$path = realpath( $dir.'/../');
        $tpl_file = $path . '/templates/schumer_table_template.html';

        // If we received a suffix, check if it is valid.
        if ($alt_template) {
            $tpl_new_path = realpath(dirname(__FILE__) . '/../templates/schumer_table_template_' . $alt_template . '.html');
            $tpl_file = is_file($tpl_new_path) ? $tpl_new_path : $tpl_file;
        }

        $html .= file_get_contents($tpl_file);
        $placeholders = $this->applyTextDecorationsToDisplayValues($placeholders);
		// replace the placeholders in the HTML template with the correct content
        foreach ($placeholders as $ph => $text) {
            // Check if the header has ReplacementCharacter - � and replace it to ®
            if ($ph === 'feedx_brand_name') {
                $text = $this->changeReplacementCharacter($text);
            }
            $html = str_replace("[[" . $ph . "]]", $text, $html);
        }
		// remove remaining placeholders, and replace with N/a
        $html = preg_replace('/\[\[.*\]\]/', "N/A", $html);

		return $html ;
    }

    /**
     * https://jira-webpals.com:8443/browse/PNP-398
     * Check if the header ('feedx_brand_name') has ReplacementCharacter - � and replace it to ®
     * we get this sign from CJ API on link-name property
     * @param - string - a text of 'feedx_brand_name' key
     * @return - string - the new text of 'feedx_brand_name' key after str_replace() function
     */
    private function changeReplacementCharacter($text) {
        $replacementCharacter = "\u{fffd}";
        $registeredSign = "\u{00AE}";
        return str_replace($replacementCharacter, $registeredSign, $text);
    }

    public function getUpdatedCards() {
        return WcmsCreditCardDatabaseHandler::getInstance()->getUpdatedCards();
    }

    /**
     * Allow the webmaster to override the card's tracking URL and Details URL, or add parameters to the query string,
     * via shortcode params
     *
     * @param $cardData = the card's complete details, after being pulled from the database in the initial Shortcode action
     * @param $atts = parameters set by the shortcode
     *
     * @return array $cardData
	 *
	 * --------- For the additional "details_link" parameter, here are the rules:
	 *	NEITHER: Use default URL for both
	 *	MAIN ONLY: Override both.
	 *	DETAILS ONLY: Default for first, override second
	 *	MAIN & DETAILS: Main overrides first; Details overrides details
	 *
	 * OR: Details = main link, unless it is overridden by the attributes.
     */
    private function overrideCardTrackingURL( $cardData, $atts ) {

		// find the index of the FEEDX_TRACKING_LINK_FIELD array, and the FEEDX_DETAILS_LINK within $cardData
		// FEEDX_TRACKING_LINK_FIELD is possibly the most important entry in this array, so we can safely assume that it's there.
		$tracking_link_index = -1;
		$details_link_index = -1;
		foreach( $cardData as $index => $key_val_pair ) {
			if($key_val_pair[CREDIT_CARD_TABLE_FIELD_META_KEY] == FEEDX_TRACKING_LINK_FIELD) {
				$tracking_link_index = $index;
			} else if($key_val_pair[CREDIT_CARD_TABLE_FIELD_META_KEY] == SHORTCODE_DETAILS_LINK_PARAM) {
				$details_link_index = $index;	// this condition is unlikely to be triggered, but it's here in case the BU changes their mind later.
												// for now, the expected behavior is that this value is always overridden by a shortcode param, if it's there at all.
												// This does not actually slow down the loop, so it stays.
			}
		}
		
        // override tracking link
        if( isset($atts[FEEDX_TRACKING_LINK_FIELD]) && !empty($atts[FEEDX_TRACKING_LINK_FIELD]) ) {
			$cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] = $atts[FEEDX_TRACKING_LINK_FIELD];
        }
		// override details link: if it is in ATTS then use it. Otherwise, use the tracking link. If The DETAILS LINK is absent, add it now.
		if($details_link_index == -1 ) {
			$details_link_index = count($cardData);
			$cardData[$details_link_index] = array(CREDIT_CARD_TABLE_FIELD_META_KEY => SHORTCODE_DETAILS_LINK_PARAM, CREDIT_CARD_TABLE_FIELD_META_VALUE => "" );
		}
		//SECONDARY: Default for first, override second
		//MAIN & SECONDARY: Main overrides first; Secondary overrides second
		if( isset($atts[SHORTCODE_DETAILS_LINK_PARAM]) && !empty($atts[SHORTCODE_DETAILS_LINK_PARAM]) ) {
			$cardData[$details_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] = $atts[SHORTCODE_DETAILS_LINK_PARAM];
		} else if( empty($cardData[$details_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE]) ) {
			$cardData[$details_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] = $cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE];
		}
		
		// add additional line to marketing copy -- how?
		// find/replace from FeedX data? (make field editable in the Dashboard?)
		// parse data for closing UL, and slip this in, there?

		
        // set query string, or append new parameters as specified (this never applies to the "DETAILS" link)
        // use "urldecode" and "urlencode" to filter bad inputs
        if( isset($atts[SHORTCODE_LINK_APPEND_QUERY_STRING]) && !empty($atts[SHORTCODE_LINK_APPEND_QUERY_STRING]) ) {
			$atts[SHORTCODE_LINK_APPEND_QUERY_STRING] =  urldecode($atts[SHORTCODE_LINK_APPEND_QUERY_STRING]);
			$old_params = explode("&amp;", $atts[SHORTCODE_LINK_APPEND_QUERY_STRING]);
			$query_string = "";
			foreach( $old_params as $idx => $str ) {
				$param = explode("=", $str);
				$query_string .= urlencode($param[0])."=".urlencode($param[1]);
				if( $idx < count($old_params) -1 ) {
					$query_string.="&";
				}
			}

            // strip leading "?" and "&", because my code already takes care of that, below
			$cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] = trim($cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE], " &?");

            // append the new query string parameters to the tracking URL
            $qmark = strpos($cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE], "?");
            if( $qmark === false ) {
				$cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] .= "?".$query_string;
            } else {
                $cardData[$tracking_link_index][CREDIT_CARD_TABLE_FIELD_META_VALUE] .= "&".$query_string;
            }

        }
		
        return $cardData;
    }
	
	/**
	 *	Some placeholders require additional "decorating" text, like mathematical units, so they make sense when displayed.
	 *	Whether or not decoration text is required may depend on various conditions.
	 *
	 *	@param $placeholders = the original array of placeholders and their values
	 *
	 *	@return $placeholders = the updated array of placeholders and their values
	 */
	private function applyTextDecorationsToDisplayValues( $placeholders ) {
		
		// list of placeholders with formatted decoration text
		$placeholders_decorating_text = array(
			"feedx_balance_transfer_intro_rate_duration" => array("decoration_text" => "[[placeholder]] [[month]]", "rule" => "is_numeric"),
			"feedx_purchase_intro_rate_duration" => array("decoration_text" => "[[placeholder]] [[month]]", "rule" => "is_numeric"),
		);
		
		// When you have numbers, sometimes you have 0, 1, or many.
		// This list gives the 0, 1, and MANY spellings of the given base unit.
		$units = array(
			"month" => array("zero" => "months", "one" => "month", "many" => "months")
		);
		
		
		foreach( $placeholders_decorating_text as $index => $conditions ) {
			if( isset( $placeholders[$index] ) ) {
				switch($conditions["rule"]) {
					
					case 'is_numeric':		// numbers that require units
						// handle comma-separated numbers as numbers instead of strings
						$raw_number = str_replace(",", "", $placeholders[$index]);
						if( is_numeric( $raw_number ) ) {
							
							// store the original value
							$one_two_many_lots = $this->discworldTrollMath( $raw_number );
							
							$conditions["decoration_text"] = str_replace("[[placeholder]]", $placeholders[$index], $conditions["decoration_text"]);
							foreach( $units as $name => $spellings ) {
								$conditions["decoration_text"] = str_replace("[[".$name."]]", $spellings[$one_two_many_lots], $conditions["decoration_text"]);
							}
							$placeholders[$index] = $conditions["decoration_text"];
							
						}
						break;
						
					default:
						$placeholders[$index] = str_replace("[[placeholder]]", $placeholders[$index], $conditions["decoration_text"]);
				}
			}
		}
		return $placeholders;
	}
	
	/**
	 *	For units and formatting purposes, determine whether a given number is "zero", "one", or "many".
	 *  The function derives its name from Terry Pratchett's "Discworld," and the way that trolls counted in Base4
	 *  GNU Terry Pratchett
	 *
	 * @param $number = the input number
	 *
	 * @return string = the string describing the number
	 */
	private function discworldTrollMath( $number ) {
		if( $number == 0 ) {
			return "zero";
		} else if( $number == 1 ) {
			return "one";
		} else {
			return "many";
		}
	}

	/**
	 * Download an image from the specified URL and attach it to the credit card by internal ID.
	 *
	 * @param int $cardVersionId
	 *   The credit card internal ID.
	 * @param string $imageUrl
	 *  The URL from which to download the image.
	 *
	 * @return int|bool
	 *   Meta ID if the key didn't exist, true on successful update, false on failure.
	 */
	public static function insertCreditCardImageFileToMediaLibrary( $cardVersionId, $imageUrl ) {
		// Make sure we have the needed WordPress dependencies.
		require_once( ABSPATH . 'wp-admin/includes/media.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/image.php' );

		// Save the image.
		$image_id = media_sideload_image( $imageUrl, 0, null, 'id' );

		if ( is_numeric( $image_id ) ) {
			// Delete the old image.
			if ( $cardOldImageId = WcmsCreditCardDatabaseHandler::getInstance()->getCardMeta( $cardVersionId, [ 'feedx_image_card_id' ] ) ) {
				wp_delete_attachment( reset( $cardOldImageId ), true );
			}

			// Update the image ID meta field.
			return WcmsCreditCardDatabaseHandler::getInstance()->updateCardMeta( $cardVersionId, 'feedx_image_card_id', $image_id );
		} elseif ( is_wp_error( $image_id ) ) {
			error_log( 'FeedX could not load the credit card image into the media library: ' . $image_id->get_error_message() );
		}

		return false;
	}

	/**
     *  Check whether a remote source returns OK or error.
     *  Can be used to quickly determine whether to display a credit card image, or the default image.
     *
     * Source: https://stackoverflow.com/questions/1363925/check-whether-image-exists-on-remote-url
     *
     * @param url
     * @return bool
     */
    private function checkPathStatus($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        // don't download content
        curl_setopt($ch, CURLOPT_NOBODY, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $result = curl_exec($ch);
        curl_close($ch);
        return $result !== FALSE;
    }

    /**
     * Find a valid card image from (1) the remote card source or
     *                              (2) a default image set in the theme (THM-14388)
     *
     * @param $feedx_remote_image, corresponds to the "feedx_card_image" brand field
     *
     * @return string - the URI of a valid image, or <empty string> if there's no valid URL
     */
    private function getCardImagePath( $feedx_remote_image ) {
        // ping remote
        $remote_img_status = $this->checkPathStatus($feedx_remote_image);

        if($remote_img_status) {
           return $feedx_remote_image;
        } else {
           $default = get_theme_mod(FEEDX_THEME_DEFAULT_CREDIT_CARD_IMAGE);
           return $default === false ? "" : $default;
        }
    }


    /**
     * Override
     *
     * @param $raw_field
     * @param $cardData
     * @return array
     */
    private function overrideDisplayFieldsAndGetFinalValue( $cardData, $field) {
        foreach( $cardData as $index => $meta) {
            // override other fields, as set in the shortcode, if applicable
            if( !empty( $atts[$meta[CREDIT_CARD_TABLE_FIELD_META_KEY]] ) ) {
                $cardData[$index][CREDIT_CARD_TABLE_FIELD_META_VALUE] = $atts[$meta[CREDIT_CARD_TABLE_FIELD_META_KEY]];
            }

            // pick up the value that the rest of this function will work with
            if( $meta[CREDIT_CARD_TABLE_FIELD_META_KEY] === $field) {
                $raw_field = $cardData[$index][CREDIT_CARD_TABLE_FIELD_META_VALUE];
            }
        }
        return $raw_field; //$cardData;
    }

    /**
     * @param $raw_field
     * @param $original_atts
     * @return string
     */
    public function applyHtmlFormattingToSingleFieldOutput($raw_field, $original_atts) {
        // HTML formatting rules, if applicable
        $formatted_output = $raw_field;
        if (isset($original_atts['html'])) {

            switch ($original_atts['field']) {

                case 'feedx_card_image':
                    // detect whether image exists, and if not, then use the default image from THM-14388
                    $card_url = $this->getCardImagePath($raw_field);
                    $image_width = $original_atts['width'] ? 'style="width:' . $original_atts['width'] . '%;"' : '';
                    $formatted_output = '<img src="' . $card_url . '" alt="card" ' . $image_width . '/>';
                    break;

                default:

            }

        }
        return $formatted_output;
    }
}
