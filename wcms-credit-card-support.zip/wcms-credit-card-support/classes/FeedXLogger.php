<?php

class FeedXLogger {
	
	// instance of singleton class
    protected static $instance = null;
	
	public $LOGDIR;
    const LOG_UPDATE_POST_DATES = "posts-with-widgets-last-updated";
    const LOG_RECEIVED_DATA_FROM_FEEDX = "feedx-data-received";
	
    private function __construct(){
        $this->LOGDIR = realpath(dirname(__FILE__) . '/../logs/');
    }
	
	public static function getInstance(){
        if (!isset(self::$instance)) {
            self::$instance = new FeedXLogger();
        }
	}

    /**
     * The actual write-to-log function
     *
     * @param $file 	(string) = one of the class's constants (see above)
     * @param $message	(string) = the actual content being added to the log.
     */
	public function log( $file, $message ) {
		$log = fopen( $this->getActiveLog($file), 'a' );
		fwrite( $log, date('[Y-m-d h:i:s]') . " - " . $message . "\r\n");
		fclose($log);
	}

    /**
     * Derive the actual log file's name from the "logs" directory, the specified filename, and today's date
     * This will rotate the logs
     *
     *	@param $filename (string) = one of the constants (see above) that is the base name of a log file
     *  @return the filename (string)
     */
	private function getActiveLog( $filename ) {
		return self::LOGDIR . $filename ."__". date('Y-m-d') . ".log";
	}
}