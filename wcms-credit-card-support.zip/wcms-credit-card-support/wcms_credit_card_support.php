<?php

/**
 * Plugin Name: WCMS Credit Card Support
 * Description: Adds the ability to get Updated Credit Cards Data
 * Version: 1.126.1
 */

// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;
 
// --------------- REQUIRES/INCLUDES for main files ---------------
require_once(dirname(__FILE__) . '/constants/wcms_credit_cards_globals.php');
require_once(dirname(__FILE__) . '/api/credit-cards-api.php');
require_once(dirname(__FILE__) . '/classes/WcmsCreditCardHandler.php');
require_once (dirname(__FILE__) . '/dashboard/set-default-card-image.php');
// -------------------- STYLESHEETS AND SCRIPTS -------------------
/**
 * NOTE: When the plugin's CSS gets imported from the TOOLS menu field, (see "/dashboard/submit-css.php")
 * This section gets replaced. Maybe on-submit, that form should write the submitted CSS to a file, and import the file here?
 */

add_action( 'wp_enqueue_scripts', 'add_feedx_scripts' );
function add_feedx_scripts() {
       wp_register_script( 'feedx_shortcode_script', plugin_dir_url(__FILE__)."assets/js/schumer_table.js", array ( 'jquery' ), 1.0, true);

       // switch, based on the site
	   $default_css = "doughroller-style.css";
       $select_css = array(
			"moneyunder30.com" => "mu30-style.css",
			"dev.moneyunder30.com" => "mu30-style.css",
			"qa.fozzie.env" => "mu30-style.css",
			"dev.local.com" => "mu30-style.css",
			"greedyrates.ca" => "greedy-style.css",
			"doughroller.net" => "doughroller-style.css",
			"doughroller.com" => "doughroller-style.css",
			"doughdev.wpengine.com" => "doughroller-style.css",
			"devdoughroller.wpengine.com" => "doughroller-style.css",
			"nonpalcon.com" => "doughroller-style.css"
       );
       $file = $select_css[ $_SERVER['HTTP_HOST']];
	   
	   if( empty( $file ) ) {
		   $file = $default_css;
	   }

       wp_enqueue_style('feedx_shortcode_style', plugin_dir_url(__FILE__)."assets/css/schumer_table/".$file );
       wp_enqueue_script( 'feedx_shortcode_script');
}

// ------------------------ INSTALL PLUGIN ------------------------
function install_plugin(){
    require_once(dirname(__FILE__) . '/classes/WcmsCreditCardDatabaseHandler.php');
    WcmsCreditCardDatabaseHandler::getInstance()->createTables();
    create_credit_card_user();
	
	// install initial schema
	$schema_json_from_file = file_get_contents(dirname(__FILE__) . '/data/schema.json');
	$schema = json_decode($schema_json_from_file);
	update_option(WP_OPTIONS_CREDIT_CARD_DATA_KEYS, $schema->credit_cards_handle->data);
}
/**
 *	If no user data is passed from FeedX, then use these default values.
 *
 */
function create_credit_card_user($user_name = "ccAdmin", $random_password = "h1899!hR&U!sMMuF#P58uU()", $user_email = "ccAdmin.noreply.com"){

    $isUserCreated = false;
    $user_id = username_exists( $user_name );
    if ( !$user_id and email_exists($user_email) == false ) {
        //$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
        $user_id = wp_create_user( $user_name, $random_password, $user_email );
        $isUserCreated =true;
    }

    return $isUserCreated;
}
// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'install_plugin');

// ----------------------- AUTH TOKEN HOOKS -----------------------

// add hooks of jwt-authentication-for-wp-rest-api plugin only if plugin exists
function save_user_jwt_token( $data  ) {
   if (!empty($data['token']) && !empty($data['user_id'])){
       WcmsCreditCardDatabaseHandler::getInstance()->addUserToken($data['user_id'], $data['token']);
   }

   return $data;
}
add_filter('jwt_auth_token_before_dispatch', 'save_user_jwt_token');

/**
 * function set token expiration date
 * the default is 1 week, we can override it here.
 *
 * @param $expire
 * @return int
 */
function change_user_jwt_token_expiration($expire){

    return $expire;
}
add_filter( 'jwt_auth_expire', 'change_user_jwt_token_expiration');


// --------------------- DASHBOARD INTERFACES ---------------------

// upload CSS to database
require_once( dirname(__FILE__).'/dashboard/submit-css.php');

// AJAX for mapping FeedX cards to actual brands
require_once( dirname(__FILE__).'/dashboard/feedx-ajax-card-to-brand.php');

// on submitting a new brand
require_once( dirname(__FILE__).'/dashboard/submit-new-brand.php');

// ----------------------------- MAIN -----------------------------

new WcmsCreditCardHandler();
