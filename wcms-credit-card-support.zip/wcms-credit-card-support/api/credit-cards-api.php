<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

// Update the raw card data in the database
require_once dirname(__FILE__).'/../classes/CreditCardsRestServer.php';

$credit_cards_rest_server = new CreditCardsRestServer();
$credit_cards_rest_server->hookRestServer();
