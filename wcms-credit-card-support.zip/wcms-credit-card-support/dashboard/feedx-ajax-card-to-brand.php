<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

/**
 * import CSS and JS for brand page
 *
 */
add_action( 'admin_enqueue_scripts', 'load_feedx_css' );
function load_feedx_css() {
	global $_WCMS_CCS_PLUGIN_URL_BASE;
	if( ! in_array($hook, array("post.php", "post-new.php") ) ) {
		return;
	}
	
	wp_enqueue_style( 'admin-feedx-css', $_WCMS_CCS_PLUGIN_URL_BASE.'assets/css/dashboard/feedx-brand.css', false, '1.0.0' );
}
add_action('admin_enqueue_scripts', 'load_feedx_js' );
function load_feedx_js($hook) {
	global $_WCMS_CCS_PLUGIN_URL_BASE;
	if( ! in_array($hook, array("post.php", "post-new.php") ) ) {
		return;
	}
	
	wp_register_script( 'feedx_js', $_WCMS_CCS_PLUGIN_URL_BASE.'assets/js/match-card-to-brand.js', array( 'jquery' ));
    wp_enqueue_script( 'feedx_js' );
	
	wp_register_script( 'feedx_js_validate', $_WCMS_CCS_PLUGIN_URL_BASE.'assets/js/validate-card-to-brand.js', array( 'jquery' ));
    wp_enqueue_script( 'feedx_js_validate' );
}

/**
 * AJAX destination, for retrieving all credit card and bank data.
 * 
 *
 */
add_action( 'wp_ajax_nopriv_feedx_match_card_to_brand', 'feedx_match_card_to_brand' );
add_action( 'wp_ajax_feedx_match_card_to_brand', 'feedx_match_card_to_brand' );
function feedx_match_card_to_brand() {
	
	$full_cc_data = get_main_query_results();
	
	$brand_id = getPostIdFromAJAX();
	$selected_bank = get_post_meta($brand_id, FEEDX_BRAND_BANK_KEY, true);
	$selected_card_id = get_post_meta($brand_id, FEEDX_BRAND_CARD_KEY, true);
	$selected_esc_html = wipeAllHTMLSpecialChars($selected_card_id);
	
	// organize all output by card, and by bank.
	$unique_list_of_bank_data = array();
	foreach( $full_cc_data['results'] as $row ) {

		if( ! isset($unique_list_of_bank_data[$row['issuer_id']]) ) {
			$unique_list_of_bank_data[$row['issuer_id']] = convertQueryResultRowToStructuredArray($row);
		}
		if( empty($unique_list_of_bank_data[$row['issuer_id']]['cards'][$row['inner_version_id']])) {
			$unique_list_of_bank_data[$row['issuer_id']]['cards'][$row['inner_version_id']] = cardBaseArray($row);
		}
		
		$unique_list_of_bank_data[$row['issuer_id']]['cards'][$row['inner_version_id']][$row['meta_key']] = $row['meta_value'];
		
	}
	
	foreach( $unique_list_of_bank_data as $key => $val ) {
		$unique_list_of_bank_data[$key]['cards'] = array_values($unique_list_of_bank_data[$key]['cards']);
		if( $key == $selected_bank ) {
			for( $idx = 0; $idx < count($unique_list_of_bank_data[$key]['cards']); $idx++ ) {
				//error_log(print_r($unique_list_of_bank_data[$key]['cards'][$idx], true));
				if($selected_esc_html == wipeAllHTMLSpecialChars($unique_list_of_bank_data[$key]['cards'][$idx][FEEDX_UNIQUE_NAME_FIELD]) ) {
					$selected_card = $idx;
				}
			}
		}
	}
	
	$out = array("bank_data_by_bank_id" => $unique_list_of_bank_data,
				 "brand_bank" => $selected_bank,
				 "brand_card" => $selected_card,
				 "card_id" => $selected_card_id,
				 //"card_id_html" => $selected_esc_html,		// for debugging, only
				 //"sql"		=> $full_cc_data['sql'],		// for debugging, only
				 );
	
	echo json_encode( $out );
	
	die();
}

/**
 * Functions that take long, messy blocks of code that really ought to be one line
 * 			 and reduce them to one line.
 *
 */
function convertQueryResultRowToStructuredArray( $row ) {
	
	return array("id" => $row[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID],
		  "nicename"  => $row[CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME],
		  "cards"	  => array()
		);
}
function cardBaseArray( $row ) {
	
	//return array($row[CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID] => array(
	return array(
								   'inner_version_id'  => $row[CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID],
								   'cc_name'		   => $row['cc_name'],
								   'creation_time'	   => $row[CREDIT_CARD_TABLE_FIELD_TIME_CREATION]
								);
	//						);
	
}

function get_main_query_results() {
	
	global $wpdb;
	
	$query = 'SELECT cc.'.CREDIT_CARD_TABLE_FIELD_AUTO_ID.', '.
		
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID.', '.
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME.' as cc_name, '.
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID.', '.
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME.', '.
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION.', '.
								  ' ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE.', '.
								   
								  ' cc.'.CREDIT_CARD_TABLE_FIELD_META_KEY.', '.
								  ' cc.'.CREDIT_CARD_TABLE_FIELD_META_VALUE.','.
								  ' cc.'.CREDIT_CARD_TABLE_FIELD_TIME_CREATION.
		
			  ' FROM '.CREDIT_CARD_VERSIONS_TABLE_NAME.' ccv '.
			  '	INNER JOIN '.CREDIT_CARD_TABLE_NAME.' cc '.
			  '	ON ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID.' = cc.'.CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID.' AND ccv.'.CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE.' = "active"';
	
	$query_results = $wpdb->get_results($query, ARRAY_A);
	
	return array("sql"=>$query,
				 "results"=>$query_results);
}

/**
 * The POST ID is passed as an environment variable.
 * Don't let users mess with this, by messing with the address bar, or something.
 */

function getPostIdFromAJAX() {
	parse_str(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_QUERY), $url_query_string);
	return $url_query_string["post"];	
}

/**
 * AJAX validation, to ensure that two brands are not matched to the same card.
 *
 *
 **/
add_action( 'wp_ajax_nopriv_feedx_validate_card_in_brand', 'feedx_validate_card_in_brand' );
add_action( 'wp_ajax_feedx_validate_card_in_brand', 'feedx_validate_card_in_brand' );
function feedx_validate_card_in_brand() {
	
	$bank = $_POST['bank'];
	$card = $_POST['card'];
	$brand_id = getPostIdFromAJAX();
	
	$response = array();
	if( ! in_array($bank, array(null, "null", "")) && ! in_array($card, array(null, "null", "")) ) {
		$brands_using_this_card = feedx_validation($bank, $card, $brand_id);
		$validation = count($brands_using_this_card['results']) === 0;
		
		$response = array("code" => "", 
						  "message" => "");
		if($validation) {
			$response = array("code" => "OK", 
							  "message" => "This is bank/card pair is not matched to a brand, yet.",
							  "brands" => $brands_using_this_card['results'],
							  "sql" => preg_replace("/\s+/", " ",$brands_using_this_card['sql'])
							  );
		} else {
			$response = array("code" => "ERROR", 
							  "message" => "This is bank/card pair is already matched to a brand.",
							  "brands" => $brands_using_this_card['results'],
							  "sql" => preg_replace("/\s+/", " ",$brands_using_this_card['sql'])
							  );
		}
	} else {
			$response = array("code" => "OK", 
							  "message" => "The data is blank."
							  );
	}
	echo json_encode( $response ); die();
}

function feedx_validation($bank, $card, $brand_id) {
	
	global $wpdb, $table_prefix;
	$query = $wpdb->prepare(
					   'SELECT brand.id AS brand_id, brand.post_title AS brand_name FROM '.$table_prefix.'postmeta bank 
																					INNER JOIN '.$table_prefix.'postmeta card ON bank.post_id = card.post_id
																					INNER JOIN '.$table_prefix.'posts brand ON bank.post_id = brand.id
														
						WHERE bank.meta_key = "'.FEEDX_BRAND_BANK_KEY.'" AND bank.meta_value = %s
						AND card.meta_key = "'.FEEDX_BRAND_CARD_KEY.'" AND card.meta_value = %s
						AND brand.id <> %s',
					
						array($bank, htmlspecialchars($card), $brand_id)
					);
	
	$results = $wpdb->get_results($query, ARRAY_A);
	
	return array("results" => $results,
				 "sql" => $query);	
}


/**
 * Fixes a bug where card names won't match because of HTML encoding problems.
 * Solution is to remove all of that weirdness.
 * Source: https://stackoverflow.com/questions/7128856/strip-out-html-and-special-characters
 */
function wipeAllHTMLSpecialChars( $string ) {
	return trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($string))))));
}
