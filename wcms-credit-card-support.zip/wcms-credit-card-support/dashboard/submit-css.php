<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;
require_once dirname(__FILE__).'/../constants/wcms_credit_cards_globals.php';

// create custom plugin settings menu
add_action('admin_menu', 'wcms_credit_card_support_menu');
function wcms_credit_card_support_menu() {

	//create new top-level menu
	add_management_page('Credit Card CSS Settings', 'Credit Card Support', 'administrator', __FILE__, 'wcms_credit_card_support_css_settings_page' );

	//call register settings function
	add_action( 'admin_init', 'register_wcms_credit_card_support_settings' );
}

function register_wcms_credit_card_support_settings() {
	register_setting( 'wcms-credit-card-support-css-settings-group', 'wcms_credit_card_shortcode_css' );
}


add_action( 'admin_head', 'import_submit_css_stylesheet' );
function import_submit_css_stylesheet() {
	global $_WCMS_CCS_PLUGIN_URL_BASE;
	?>
	<link href="<?= $_WCMS_CCS_PLUGIN_URL_BASE.'/assets/css/dashboard/submit-css.css'; ?>" rel="stylesheet" type="text/css" media="all" />
	<?php
}


function wcms_credit_card_support_css_settings_page() {
	
	?>
	<div class="wcms-credit-card-support-import-css">
	<h1>WCMS Credit Card Support Dashboard</h1>

	<form method="post" action="options.php">
		<?php settings_fields( 'wcms-credit-card-support-css-settings-group' ); ?>
		<?php do_settings_sections( 'wcms-credit-card-support-css-settings-group' ); ?>
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th scope="row">Credit Card Shortcode<br />Custom CSS</th>
						<td><textarea name="wcms_credit_card_shortcode_css"><?= esc_attr( get_option('wcms_credit_card_shortcode_css') ); ?></textarea></td>
					</tr>
				</tbody>
			</table>
		
		<?php submit_button(); ?>

	</form>
	</div>
<?php } ?>
