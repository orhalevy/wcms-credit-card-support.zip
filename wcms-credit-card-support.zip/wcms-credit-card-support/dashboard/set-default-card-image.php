<?php

/** THM-14388 - User can set the default credit card image from the "Appearance > Customization" dashboard interface
 * to be displayed, if a card's image imported from FeedX is missing.
 */
add_action('customize_register', 'feedx_settings_customizer');

/**
 * Add FeedX default card image selector to "Appearance > Customization" options.
 * @param $wp_customize
 */
function feedx_settings_customizer($wp_customize) {
    $wp_customize->add_section(
        'feedx_settings',
        array(
            'title' => 'FeedX Settings',
            'description' => 'Upload N/A card image',
            'priority' => 35
        )
    );

    $wp_customize->add_setting(FEEDX_THEME_DEFAULT_CREDIT_CARD_IMAGE);

    $wp_customize->add_control(
        new WP_Customize_Upload_Control(
            $wp_customize,
            FEEDX_THEME_DEFAULT_CREDIT_CARD_IMAGE,
            array(
                'label' => 'This card image will show up once a card is unavailable.',
                'section' => 'feedx_settings',
                'settings' => FEEDX_THEME_DEFAULT_CREDIT_CARD_IMAGE
            )
        )
    );
}