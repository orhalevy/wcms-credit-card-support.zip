<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

/**
 *	Hook into Wordpress "publish" and "update" -post options, in order to limit the "save_post" actions
 *	We don't want "save_post" to trigger on auto-save drafts, for example.
 *
 *	Also, added a check to these functions, to make sure this stuff only runs for BRAND objects.
 */

 
 /**
  *	The "save_post" hook is the appropriate place to connect this process, because the meta data is already submitted, thus avoiding the need for clever, yet superfluous tricks
  * However, that hook executes under several different circumstances, most of which are not relevant
  */
add_action('save_post', 'modify_default_linksets', 10, 3);
function modify_default_linksets( $id, $post, $update ) {

    // this function relies on WCMSLinkSets2. If it's not available, or if methods that I need are not defined, then stop this process now
    if( ! (is_plugin_active("wcms_link_sets_2/wcms_link_sets_2.php") &&
        method_exists("WCMSLinkSets2", "get_default_links_by_brand_ids") ) ) {
        return;
    }
	
	// Testing shows that this function is trigged just by setting up a blank draft post when the user 
	// clicks "ADD NEW" and it isn't specific to post types (as opposed to the "{$status}_{$post_type}" hooks).
	// This check kills this subroutine when it is not relevant.
	if( strtolower($post->post_type) !== 'brand' || strtolower($post->post_status) !== 'publish') {
		return;
	}
	
	// not all brands have this field filled by default.
	$tracker_link = get_post_meta($id, 'feedx_brand_tracking_link', true);
	if( empty($tracker_link) ) {
		return;
	}
	
	// different behaviors, depending on whether we're creating a new brand, or updating an existing one.
	// The "$update" parameter seems to to throw a lot of false positives, but when it is correctly "false", that use-case still needs to be accounted for.
	// Therefore, we keep this check here, but also run a different check inside the main update function.
	if( $update === true ) {
		//error_log( __FUNCTION__ ."(): update");
		update_default_linksets( $id, $post, $tracker_link );
	} else if ($update === false) {
		//error_log( __FUNCTION__ ."(): create");
		create_linksets_entry( $id, $post, $tracker_link );	
	} else {
		error_log( __FUNCTION__ ."(): Failure to define the UPDATE param.");
	}
}

/**
 *	When a new BRAND is published, a new LinkSet is created.
 *
 */
function create_linksets_entry( $id, $post, $tracker_link ) {

    // this function relies on WCMSLinkSets2. If it's not available, or if methods that I need are not defined, then stop this process now
    if( ! (is_plugin_active("wcms_link_sets_2/wcms_link_sets_2.php") &&
            method_exists("WCMSLinkSets2", "public_wcmsls2_insert_new_links_to_ls") ) ) {
        return;
    }

	$link_to_insert =	array( 
							array('brand_id' => $id, 
								  'pretty_link' => "links/".$post->post_name,
								  'tracker_id' => "", //<<PALSYS_TRACKER>> ,
								  'tracker' => $tracker_link, //$_POST['feedx_brand_tracking_link'],
								  'is_default' => 1,
								  'active' => 1,
								  'sub_id' => " ", //$brand_data[$key]['linksets_data']['sub_id'],
								  'sub_id_parameter' => "", //$brand_data[$key]['linksets_data']['sub_id_parameter'],
								  'category_id' => null)
						);
	$linksets = WCMSLinkSets2::init();
	$inserted_links = $linksets->public_wcmsls2_insert_new_links_to_ls($link_to_insert);
	
	$link_to_insert[0]['id_ls'] = $inserted_links[0]['id_ls'];
	
	// first entry, so same data for both of the first two parameters.
	update_linksets_history( $link_to_insert[0], $link_to_insert[0], $post->post_title );
	
}

/**
 *	When a BRAND is updated, it's LinkSets data should be checked, and updated if necessary.
 *
 */
function update_default_linksets($id, $post, $tracker_link) {

    // this function relies on WCMSLinkSets2. If it's not available, or if methods that I need are not defined, then stop this process now
    if( ! (is_plugin_active("wcms_link_sets_2/wcms_link_sets_2.php") &&
        method_exists("WCMSLinkSets2", "public_wcmsls2_update_links_in_ls") ) ) {
        return;
    }

	$linksets = WCMSLinkSets2::init();
	$default_linksets = $linksets->get_default_links_by_brand_ids( array($id) );
	
	// that "$update" parameter throws false positives :(
	error_log( __FUNCTION__ ."(): data -  ".print_r($default_linksets, true));
	if( empty($default_linksets ) ) {
		create_linksets_entry( $id, $post, $tracker_link );
		return;
	}

	// If neither BRAND_NAME nor the TRACKER changed between this version and the old version, don't bother updating
	if( $default_linksets[0]['tracker'] !== $tracker_link ||
		$default_linksets[0]['pretty_link'] !== "links/".$post->post_name
	) {		
		$link_to_update = array(
								array( 'brand_id' => $id, 
											  'id_ls' => $default_linksets[0]['id_ls'],
											  'pretty_link' => "links/".$post->post_name,
											  'tracker_id' => "", //<<PALSYS_TRACKER>> ,
											  'tracker' => $tracker_link,
											  'is_default' => 1,
											  'active' => 1,
											  'sub_id' => $default_linksets[0]['sub_id'] == null ? " " : $default_linksets[0]['sub_id'],
											  'sub_id_parameter' => $default_linksets[0]['sub_id_parameter'],
											  'category_id' => null)
							);
		$linksets->public_wcmsls2_update_links_in_ls($link_to_update);
	
		update_linksets_history( $default_linksets[0], $link_to_update[0], $post->post_title );
	}
	
}

/**
 *	New entries in LinkSets history can be created on either PUBLISH or EDIT actions for BRANDs.
 *
 */
function update_linksets_history( $old_data, $new_data, $brand_name ) {
	
		// This is the structure that Vlad said it's supposed to look like:
		$new_link_for_history = array(
	
			"id_ls" => $new_data['id_ls'], //( isset($brand_data["id_ls"]) ? $brand_data["id_ls"] : $brand_data['linksets_data']['id_ls']), //$id_of_last_insert,
			"active" => 1,
			"pretty_link" => $new_data['pretty_link'], //$brand_data['linksets_data']["pretty_link"],
			"is_default" => 1,
			"tracker" => $new_data['tracker'], //$brand_data['card_data']['feedx_brand_tracking_link'],
			"category_id" => $new_data['category_id'],
			"category_name" => 'Uncategorized',
			"brand_id" =>  $new_data['brand_id'],
			"brand_name" => $brand_name, //$brand_data['card_data']['feedx_brand_name'],
			"tracker_id" => "", //$palsys_tracker_id,		// we're not using PalSys for this
			"sub_id" => 1,
		//	"sub_id_parameter" => '', //this is set manually, by the user
		
			"original_link" => array (
				"id_ls" =>  $old_data['id_ls'],
				"active" => 0,
				"pretty_link" =>  $old_data["pretty_link"],
				"is_default" => 0,
				"tracker" =>  $old_data['tracker'],
				"category_id" =>  $old_data['category_id'],
				"category_name" => 'Uncategorized',
				"brand_id" =>  $old_data['brand_id'],
				"brand_name" =>  $brand_name,
				"tracker_id" =>  $old_data['tracker_id'],
				"sub_id" => 0,
				"sub_id_parameter" => $old_data['sub_id_parameter']
		));
		$linksets_instance = $linksets = WCMSLinkSets2::init();
		$linksets_instance->public_wcmsls2_insert_links_to_ls_history(array( $new_link_for_history ) , 'default');
	
}
