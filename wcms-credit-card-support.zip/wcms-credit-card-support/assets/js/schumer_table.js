(function () {
    /** @class */
    var SchumerTable = (function () {
        function SchumerTable(uuid) {
            this.ACTIVE_CLASS_NAME = 'active';
            this.numberOfShownList = 3;
            this.isCollapsed = false;
            this.widgetWrapper = document.querySelector('.schumer_table_widgetWrapper.' + uuid);

            this.initData();
        }

        SchumerTable.prototype.initData = function () {
            // // ==========
            // //each bank can define a different format for “credit score”, this code mapping the value of credit score to format - 'Poor/Fair/Good/Excellent'.
            // var scoreListSelected = this.widgetWrapper.querySelector('.score_list_selected');
            // var scoreListStr = scoreListSelected.innerText;
            // if (scoreListStr.toLowerCase() !== 'no credit check') {
            //     var scoreList = scoreListStr.split(/[\s-,\/]+/);
            //     var sortOrder = ['poor', 'fair', 'good', 'excellent'];
            //     scoreListSelected.innerText = this.sortList(scoreList, sortOrder).join('/');
            // }
            // // =====================================

            this.collapseListEventRegister();
            if (this.isCollapsed) {
                this.showMoreEventRegister();
            }
        };

        SchumerTable.prototype.showMoreEventRegister = function () {
            var _this = this;
            var showMoreLessHtmlElement = this.widgetWrapper.querySelector('.show_more_less_wrapper');
            showMoreLessHtmlElement.style.display = 'block';
            var collapseMarketingInfoList = this.widgetWrapper.querySelector('.marketing_info_list.collapse_list');

            showMoreLessHtmlElement.addEventListener('click', function () {
                this.classList.toggle(_this.ACTIVE_CLASS_NAME);

                if (collapseMarketingInfoList.style.maxHeight) {
                    collapseMarketingInfoList.style.maxHeight = null;
                } else {
                    collapseMarketingInfoList.style.maxHeight = collapseMarketingInfoList.scrollHeight + 'px';
                }
            });
        };

        SchumerTable.prototype.collapseListEventRegister = function () {
            var dbMarketingInfoList = this.widgetWrapper.querySelector('.schumer_body_wrapper .marketing_info ul');
            if (!dbMarketingInfoList) {
                // if ul is not exist and we get another format of marketing info we'll create ul with the data.
                dbMarketingInfoList = this.createUnOrderList();
                // if we don't know the format to handle with, the function wont' be execute at all,
                // the text will be show up as a regular string, without bullets and show more/less for this schumer table.
                if (!dbMarketingInfoList) {
                    return;
                }
            }
            dbMarketingInfoList.classList.add('marketing_info_list');
            dbMarketingInfoList.classList.add('db_list');

            if (dbMarketingInfoList.children.length > this.numberOfShownList) {
                this.isCollapsed = true;
                var collapseMarketingInfoList = document.createElement('UL');
                collapseMarketingInfoList.classList.add('marketing_info_list');
                collapseMarketingInfoList.classList.add('collapse_list');
            }

            var marketingListItems = this.widgetWrapper.querySelectorAll('.schumer_body_wrapper .marketing_info ul li');
            [].forEach.call(marketingListItems, function (li, index) {
                li.classList.add('marketing_info_item');
                var spanHtmlElement = document.createElement('SPAN');
                spanHtmlElement.classList.add('item_text');
                spanHtmlElement.appendChild(li.childNodes[0]);
                li.appendChild(spanHtmlElement);
                if (collapseMarketingInfoList) {
                    if ((index + 1) > this.numberOfShownList) {
                        collapseMarketingInfoList.appendChild(li);
                    }
                }
            }.bind(this));
            if (collapseMarketingInfoList && this.isCollapsed) {
                dbMarketingInfoList.parentNode.insertBefore(collapseMarketingInfoList, dbMarketingInfoList.nextSibling);
            }
        };

        SchumerTable.prototype.createUnOrderList = function () {
            //if we don't get ul/li format for marketing_info, this function will execute.
            var marketingInfo = this.widgetWrapper.querySelector('.schumer_body_wrapper .marketing_info');
            var ulElement = document.createElement('UL');
            var dbData = marketingInfo.firstChild.data.trim();

            // if we get a string
            if (typeof dbData === 'string') {
                // string with bullets format
                var bulletSymbolUnicode = '\u2022';
                if (dbData.indexOf(bulletSymbolUnicode) !== -1) {
                    var marketingInfoList = dbData.split(bulletSymbolUnicode);
                    for (var i = 0; i < marketingInfoList.length; i++) {
                        if (!marketingInfoList[i]) continue;
                        marketingInfoList[i] = marketingInfoList[i].trim();
                        var liElement = document.createElement('li');
                        liElement.innerHTML = marketingInfoList[i];
                        ulElement.appendChild(liElement);
                    }
                    // removing the old format data
                    marketingInfo.firstChild.data = '';
                    // insert the new format data.
                    marketingInfo.insertBefore(ulElement, marketingInfo.firstChild);
                }
            }
            // returning back ul element, or null if we're not finding the symbol inside the text.
            return marketingInfo.querySelector('ul');
        };

        SchumerTable.prototype.sortList = function (list, sortOrder) {
            var ordering = {};
            for (var i = 0; i < sortOrder.length; i++) {
                ordering[sortOrder[i]] = i;
            }

            list.sort(function (a, b) {
                var x = a.toLowerCase();
                var y = b.toLowerCase();
                return (ordering[x] - ordering[y]);
            });
            return list;
        };

        return SchumerTable;
    })();

    var schumerTableCollection = document.querySelectorAll('.schumer_table_widgetWrapper');

    [].forEach.call(schumerTableCollection, function (schumerTable, index) {
        var uuId = 'schumer_table_' + index;
        schumerTable.classList.add(uuId);

        new SchumerTable(uuId);
    });
})();