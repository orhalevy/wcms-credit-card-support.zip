
$(document).ready(function () {
	new CardBrandMatching();
});


var CardBrandMatching = (function () {
	/**
	 * Constuctor
	 */
	function CardBrandMatching() {
		this.FEEDX_UNIQUE_NAME_FIELD = "feedx_custom_brand_name";
		// store the parent element
		this.$home = $('div[data-name="feedx_select_bank"]').parent();
		this.$selectBank = $('div[data-name="feedx_select_bank"] .acf-input select');
		this.$selectCardName = $('div[data-name="feedx_card_name"] .acf-input select');
		this.$creditCardNaCheckbox = $('div[data-name="credit_card_na_from_feedx"] .acf-input input');
		this.$isNotFeedxObject = $('div[data-name="this_is_not_a_feedx_object"]');
		this.$isNotFeedxObjectCheckbox = $('div[data-name="this_is_not_a_feedx_object"] .acf-input input');
		this.$feedxDataFields = $('div[data-name^="feedx_"] .acf-input input');

		// Private Variable of credit card data source
		var _ccData = null;

		//make checkbox value unchangable by user
		this.makeCheckboxUnchecked(this.$creditCardNaCheckbox);
		this.selectBankCardToggle(true);

		this.getCreditCardData();
		this.onSelectBank();
		this.onSelectCard();
		this.onNotFeedxObjectCheckboxChecked();

		// Public methods have access to a private variable
		this.setCCData = function (data) {
			_ccData = data;
		};

		this.getCCData = function () {
			return _ccData;
		};
	}



	CardBrandMatching.prototype.getCreditCardData = function () {
		var _this = this;

		$.ajax({
			url: ajaxurl,	// defined by Wordpress, should be http://[site.com]/admin-ajax.php
			type: 'post',
			data: {
				action: 'feedx_match_card_to_brand'
			},
			success: function (ccData) {
				var dataSrc = JSON.parse(ccData);
				_this.setCCData(dataSrc);

				var initBank = dataSrc.brand_bank;
				var initCard = dataSrc.brand_card;

				// populate list of banks
				for (bankid in dataSrc.bank_data_by_bank_id) {
					var option = '<option value="' + bankid + '" ';
					if (bankid == initBank) {
						option += ' selected ';
					}
					option += '>' + dataSrc.bank_data_by_bank_id[bankid].nicename + '</option>';

					_this.$selectBank.append(option);
				}

				// if a bank is already saved in the system, then populate the cards for the selected bank, and display the saved card if applicable
				if (initBank != null && initBank != "" && initBank != "null") {
					_this.populateCardsMenu(initBank, initCard);
				}

				// if a card is already saved for this brand, then display its data
				if (initCard !== "" && initCard !== null) {
					_this.showCreditCardData(initBank, initCard);
				}

				// if 'This is NOT a FeedX object' is checked 'Select Bank' and 'Select Card Name'
				// will still be disabled, until this checkbox is not checked and it will be enabled.
				if (!_this.$isNotFeedxObjectCheckbox.is(':checked')) {
					_this.selectBankCardToggle(false);
				}
			},
			error: function (xhr) {
				console.error('Error: there was a problem to get credit cards data from the database.\n'
					+ 'status: ' + xhr.status + ' - ' + xhr.statusText);
			}
		});
	};

	CardBrandMatching.prototype.onSelectBank = function () {
		var _this = this;
		// when different banks are selected, repopulate the bank-option field.
		this.$selectBank.change(function () {

			// clear the list of cards, and any visible card details
			_this.$selectCardName.html("");
			_this.clearAcfFields();

			if ($(this).val() !== null && $(this).val() !== "null" && $(this).val() !== "") {
				var bank_id = $(this).val();
				_this.populateCardsMenu(bank_id, -1);
			}
		});
	};

	CardBrandMatching.prototype.onSelectCard = function () {
		var _this = this;
		this.$selectCardName.change(function () {
			//clear the checkbox when selecting a different card(because it exists in feedx, otherwise, wouldn't have been available on dropdown options)
			_this.$creditCardNaCheckbox.removeAttr('checked');

			// clear the display
			_this.clearAcfFields();

			// get the card's ID, and the bank's ID
			var cardId = $('div[data-name="feedx_card_name"] .acf-input select > option:selected').attr('index');
			var bankId = _this.$selectBank.val();

			if ($(this).val() != "" && $(this).val() != null) {
				_this.showCreditCardData(bankId, cardId)
			}

			// Hiding this is not feedx object select when selecting a card
			_this.$isNotFeedxObject.attr("hidden", true);
			_this.$isNotFeedxObject.addClass("acf-hidden");
		});
	};

	CardBrandMatching.prototype.populateCardsMenu = function (bankId, cardId) {
		var _this = this;
		var selection = _this.getCCData().bank_data_by_bank_id[bankId];

		// repopulate the list
		if (typeof selection !== "undefined") {
			var new_list = '<option value="">none</option>';
			$.each(selection.cards, function (i, card) {
				var option = '<option index="' + i + '" value="' + card[_this.FEEDX_UNIQUE_NAME_FIELD] + '"';
				if (i == cardId) {
					option += ' selected ';
				}
				option += '>' + card[_this.FEEDX_UNIQUE_NAME_FIELD] + '</option>';
				new_list += option;
			});
			this.$selectCardName.html(new_list);
		}
	};

	CardBrandMatching.prototype.showCreditCardData = function (bankId, cardId) {
		var ccBank = this.getCCData().bank_data_by_bank_id[bankId];
		var ccCard = ccBank.cards[cardId];

		for (var k in ccCard) {
			$('div[data-name="' + k + '"] .acf-input input').val(ccCard[k]);
		}

		if (!this.$isNotFeedxObjectCheckbox.is(':checked')) {
			this.$feedxDataFields.prop('readonly', true);
		}
	};

	CardBrandMatching.prototype.onNotFeedxObjectCheckboxChecked = function () {
		var _this = this;
		this.$isNotFeedxObjectCheckbox.click(function () {
			if ($(this).is(':checked')) {
				// Disable select bank and select card name select
				_this.selectBankCardToggle(true);

				// Remove readonly on all the feedx data fields
				_this.$feedxDataFields.removeAttr('readonly');
			} else {
				// Enable select bank and select card name select
				_this.selectBankCardToggle(false);

				// Add readonly on all the feedx data fields
				_this.$feedxDataFields.prop('readonly', true);
			}
		});

	};

	/**
	 * This function can disable/enable both SELECTs for matching card to brand
	 *  disable: boolean
	 */
	CardBrandMatching.prototype.selectBankCardToggle = function (disable) {
		disable = disable ? true : false; // in case of undefined
		this.$selectBank.prop("disabled", disable);
		this.$selectCardName.prop("disabled", disable);
	}

	CardBrandMatching.prototype.clearAcfFields = function () {
		this.$home.find('div.acf-field > div.acf-input input').val("");
	};

	CardBrandMatching.prototype.makeCheckboxUnchecked = function ($checkboxElement) {
		$checkboxElement.attr('onclick', 'return false;');
	};

	return CardBrandMatching;
})();