jQuery(document).ready( function() {
	
	var validated = false;
	
	jQuery('body.post-type-brand #publish').click( function(e) {
		
		var $publish_button = jQuery(this);
		
		if( ! validated ) {
			
			e.preventDefault();
			
			var bank_id = jQuery('div[data-name="feedx_select_bank"] .acf-input select').val();
			var card_name = jQuery('div[data-name="feedx_card_name"] .acf-input select').val();
			
			jQuery.ajax({
				url: ajaxurl,	// defined by Wordpress, should be http://[site.com]/admin-ajax.php
				type: 'post',
				data: {
					action: 'feedx_validate_card_in_brand',
					bank: bank_id,
					card: card_name
				},
				success: function() {}
				
			}).then(function(validation) {
				
				console.log(validation);
				
				var json_validation = JSON.parse(validation)
				console.log(json_validation);
				
				if( json_validation.code == "OK" ) {
					validated = true;
					$publish_button.trigger('click');
				} else if (json_validation.code == "ERROR") {
					alert(json_validation.message + "\n" +
						  json_validation.brands[0].brand_name + " ("+json_validation.brands[0].brand_id+")"
					
					);
				}
			});
		}
	});
});
