<?php
// --------------- BLOCK DIRECT ACCESS TO THIS FILE ---------------
defined( 'ABSPATH' ) or exit;

$_WCMS_CCS_PLUGIN_URL_BASE = plugin_dir_url(dirname(__FILE__));

const SHORTCODE_CREDIT_CARD_VISUAL = "credit_card_visual";
const SHORTCODE_CREDIT_CARD_DATA = "credit_card_data";
const WP_OPTIONS_CREDIT_CARD_DATA_KEYS = "wcms_credit_card_data_keys";
const WP_OPTIONS_CREDIT_CARD_SETTINGS = "wcms_credit_card_settings";
const SHORTCODE_PARAMS = "params";

const SHORTCODE_LINK_APPEND_QUERY_STRING = "append_query_string";
const SHORTCODE_DETAILS_LINK_PARAM = "feedx_details_link";

const TABLE_CREDIT_CARDS = "wcms_credit_cards";
const WP_PATH_UPGRAGE_DB = "wp-admin/includes/upgrade.php";

//--------status types of credit card----------
const CREDIT_CARD_STATUS_ACTIVE = "active";
const CREDIT_CARD_STATUS_ARCHIVE = "archive";
const CREDIT_CARD_STATUS_PENDING = "pending";

//--------table credit cards and columns names----------
const CREDIT_CARD_TABLE_NAME = "wcms_credit_cards";
const CREDIT_CARD_TABLE_FIELD_AUTO_ID = "id";
const CREDIT_CARD_TABLE_FIELD_META_VALUE = "meta_value";
const CREDIT_CARD_TABLE_FIELD_META_KEY = "meta_key";
const CREDIT_CARD_TABLE_FIELD_INNER_VERSION_ID = "inner_version_id";
const CREDIT_CARD_TABLE_FIELD_TIME_CREATION = "creation_time"; 
const CREDIT_CARD_TABLE_FIELD_MARKETPLACE_LINK = "marketplace_link";

const FEEDX_UNIQUE_NAME_FIELD = "feedx_custom_brand_name";
const FEEDX_TRACKING_LINK_FIELD = "feedx_brand_tracking_link";

//--------table credit cards versions and state----------
const CREDIT_CARD_VERSIONS_TABLE_NAME = "wcms_credit_cards_versions";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_AUTO_ID = "inner_version_id";

const CREDIT_CARD_VERSIONS_TABLE_FIELD_PRODUCT_ID = "feedx_card_id";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_CUSTOM_BRAND_NAME = FEEDX_UNIQUE_NAME_FIELD; //"feedx_custom_brand_name";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_ID = "issuer_id";

const CREDIT_CARD_VERSIONS_TABLE_FIELD_ADVERTISER_NAME = "issuer_name";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_VERSION = "version";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_STATE = "state";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_TIME = "update_time";
const CREDIT_CARD_VERSIONS_TABLE_FIELD_TIME_CREATION = "creation_time";

//--------feedx to brand matching fields---------------
const FEEDX_BRAND_POST_ID = "post_id";
const FEEDX_BRAND_BANK_KEY = "feedx_select_bank";
const FEEDX_BRAND_CARD_KEY = "feedx_card_name";
const CREDIT_CARD_N_A_FROM_FEEDX = "credit_card_na_from_feedx";

//--------table of tokens per user --------------------
const CREDIT_CARD_TOKENS_TABLE_NAME = "wcms_credit_cards_tokens";
const CREDIT_CARD_TOKENS_TABLE_FIELD_AUTO_ID = "id";
const CREDIT_CARD_TOKENS_TABLE_FIELD_USER_ID = "user_id";
const CREDIT_CARD_TOKENS_TABLE_FIELD_TOKEN = "token";
const CREDIT_CARD_TOKENS_TABLE_FIELD_TIME_CREATION = "last_updated";

//--------type of query -----------------------
const CREDIT_CARD_QUERY_TYPE_IGNORE = "ignore";
const CREDIT_CARD_QUERY_TYPE_SELECT = "select";
const CREDIT_CARD_QUERY_TYPE_INSERT = "insert";
const CREDIT_CARD_QUERY_TYPE_UPDATE = "update";

//--------------------other---------------------------------

const CREDIT_CARD_QUERY_FIELD_TOTAL_ROWS = "total_rows";
const CREDIT_CARD_DEFAULT_MAX_VERSION_COUNT_PER_ADVERTISER = "1";

const FEEDX_THEME_DEFAULT_CREDIT_CARD_IMAGE = "img-upload-feedx";

//--------------------api---------------------------------

const REQUEST_PARAM_MAX_VERSION_COUNT_PER_ADVERTISER = 'version_count_max_to_save';

const RESPONSE_MSG = "message";
const RESPONSE_CODE = "code_status";

const RESPONSE_STATUS_SUCCESS = 1;
const RESPONSE_STATUS_MSG_SUCCESS = "success";

const RESPONSE_STATUS_FAILED = 2;
const RESPONSE_STATUS_MSG_FAILED = "failed";

const RESPONSE_STATUS_SCHEMA_UPDATE_SUCCESS = 3;
const RESPONSE_STATUS_SCHEMA_UPDATE_MSG_SUCCESS = "schema update success";
const RESPONSE_STATUS_SCHEMA_UPDATE_FAILED = 4;
const RESPONSE_STATUS_SCHEMA_UPDATE_MSG_FAILED = "schema update failed";

const RESPONSE_STATUS_ADD_NEW_CARDS_SUCCESS = 5;
const RESPONSE_STATUS_ADD_NEW_CARDS_MSG_SUCCESS = "add cards success";
const RESPONSE_STATUS_ADD_NEW_CARDS_FAILED = 6;
const RESPONSE_STATUS_ADD_NEW_CARDS_MSG_FAILED = "add cards failed";

const RESPONSE_STATUS_CARDS_EXISTS = 7;
const RESPONSE_STATUS_CARDS_MSG_EXISTS = "this credit card version of advertiser already exists";


const RESPONSE_STATUS_CARDS_VERSION_UPDATE_SUCCESS = 8;
const RESPONSE_STATUS_CARDS_VERSION_UPDATE_MSG_SUCCESS = "updated credit cards active version success";
const RESPONSE_STATUS_CARDS_VERSION_UPDATE_FAILED = 9;
const RESPONSE_STATUS_CARDS_VERSION_UPDATE_MSG_FAILED = "updated credit cards active version failed";

const RESPONSE_STATUS_CARDS_NOT_EXISTS = 10;
const RESPONSE_STATUS_CARDS_MSG_NOT_EXISTS = "this update version for advertiser does not exists";


const RESPONSE_STATUS_CONFIG_SETTINGS_SUCCESS = 11;
const RESPONSE_STATUS_CONFIG_SETTINGS_MSG_SUCCESS = "config set success";
const RESPONSE_STATUS_CONFIG_SETTINGS_FAILED = 12;
const RESPONSE_STATUS_CONFIG_SETTINGS_MSG_FAILED = "config set failed";

const RESPONSE_STATUS_MSG_NOT_AUTHENTICATE = "authentication failed";
const RESPONSE_STATUS_MSG_ACTION_FAILED = "action failed";

//-------type of requests------------

// update requests
const REQUEST_TYPE_UPDATE = "update";
const REQUEST_SUB_TYPE_UPDATE_SCHEMA = "schema";
const REQUEST_SUB_TYPE_UPDATE_CARDS_VERSION = "update_cards_version";
const REQUEST_SUB_TYPE_UPDATE_CONFIG_SETTINGS = 'settings';

// add requests
const REQUEST_TYPE_ADD = "add";
const REQUEST_SUB_TYPE_ADD_NEW_CARDS = "add_new_cards";

//request json parameters
const REQUEST_PARAM_SUB_TYPE = "sub_type";
const REQUEST_PARAM_TYPE = "type";
const REQUEST_PARAM_CONFIG = "config";
const REQUEST_PARAM_DATA = "data";
const REQUEST_PARAM_CREDIT_CARDS_HANDLE = 'credit_cards_handle';
const REQUEST_PARAM_STATE = "state";

// response object
const RESPONSE_OBJ_KEY_RESULT = 'result';
const RESPONSE_OBJ_KEY_VERSION_EXISTS = 'isAdvertiserCardsVersionExists';
